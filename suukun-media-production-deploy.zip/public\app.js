/**
 * Suukun Media - Production Client Application
 * Zero-Google Compliant: No Google Fonts, No Analytics, No External CDNs
 */

// Timeline Occasions Data
const timelineOccasions = [
  {
    id: 'diwali-festive',
    name: 'Cultural Festival / Festive Surge',
    badge: 'High-Converting Festive Campaign',
    dateStr: 'Festival Eve • Peak Commercial Week',
    optimalTime: '07:45 PM IST',
    peakHourReason: 'Evening post-work downtime & prime festive purchasing window',
    rawCaption: 'Happy Diwali everyone! We are launching our festive collection. Check it out on our website and buy today.',
    polishedCaption: `✨ When was the last time a festive drop actually felt personal?

Tonight, we’re opening the vault. 

From day one, our mission was simple: craft pieces that don't just sit in your wardrobe, but tell the story of every celebration you step into.

⚡ THE FESTIVE VAULT IS OFFICIALLY UNLOCKED:
• First 100 orders receive our signature gold keepsake
• Guaranteed 48-hour festive express dispatch
• Zero restocks once current units are spoken for

Drop "FESTIVE" in the comments below, and our team will instantly DM your exclusive VIP checkout gateway before public release. 👇`,
    hashtags: {
      broad: ['#FestiveSeason', '#DiwaliShopping', '#LuxuryLifestyle', '#HolidayGifting'],
      niche: ['#HandcraftedInIndia', '#FestiveLookbook2026', '#FestiveFashionDrop', '#IndianD2C'],
      branded: ['#SuukunMediaClient', '#VaultCollection', '#CelebrateAuthentic'],
    },
    impressions: '120K - 180K',
    engagement: '8.9% Eng.',
    saves: '2,400+ Saves',
  },
  {
    id: 'product-launch',
    name: 'Product / Brand Launch Drop',
    badge: 'Milestone Product Launch',
    dateStr: 'Launch Day • Zero-Hour Announcement',
    optimalTime: '12:15 PM IST',
    peakHourReason: 'Midday screen break & high mobile commerce checkout intent',
    rawCaption: 'Our new software is live now. We worked hard on it. Link in bio if you want to try it out.',
    polishedCaption: `94% of founders spend 14+ hours a week fighting scattered social media workflows.

Today, that bottleneck ends. 🚀

Introducing the Next Generation Engine:
Built from 18 months of rigorous testing, we’ve stripped away every manual friction point so your brand scales on autopilot.

Here is what changes for your team immediately:
1. Precision timeline scheduling synced to audience peak hours
2. High-impact short-form video hooks written to convert
3. Zero third-party tracker bloat — pure, organic velocity

Tap the link in our bio to claim your early-bird founder license before tier-1 pricing closes at midnight. ⚡`,
    hashtags: {
      broad: ['#TechLaunch', '#SaaSGrowth', '#FounderJourney', '#SocialStrategy'],
      niche: ['#AgencyAutomation', '#ContentDistribution', '#CreatorEconomy2026'],
      branded: ['#NextGenDrop', '#BuiltToScale', '#SuukunBlueprint'],
    },
    impressions: '85K - 130K',
    engagement: '7.4% Eng.',
    saves: '1,850+ Clicks',
  },
  {
    id: 'trending-hook',
    name: 'Midweek Algorithmic Trend',
    badge: 'Viral Hook & Authority Building',
    dateStr: 'Wednesday Momentum • Prime Midweek Window',
    optimalTime: '08:30 PM IST',
    peakHourReason: 'Deep engagement wind-down period with highest save-to-bookmark ratios',
    rawCaption: 'Here are 5 tips to get more reach on social media. Hope this helps you grow.',
    polishedCaption: `Stop posting without an occasion calendar. It is costing you 70% of your organic reach. 🛑

We audited 50 brands last month. The ones generating 5x more inbound leads aren't working harder—they simply exploit 3 timeline rules:

Slide 1: Why 11 AM posts get ignored while 7:45 PM posts explode
Slide 2: The 3-second hook structure that keeps watch-time above 85%
Slide 3: How to categorize hashtags into Reach vs. Intent tiers
Slide 4: The 4-touch occasion calendar breakdown

Bookmark this carousel for your next campaign planning session. Which slide hit hardest? Comment below! 👇`,
    hashtags: {
      broad: ['#SocialMediaTips', '#MarketingGrowth', '#OrganicReach', '#ContentCreator'],
      niche: ['#SocialMediaAgency', '#HookWriting', '#InstagramGrowthHacks', '#PostingTimeline'],
      branded: ['#SuukunFramework', '#GrowthAudit', '#ScaleWithSuukun'],
    },
    impressions: '95K - 150K',
    engagement: '11.2% Eng.',
    saves: '3,100+ Bookmarks',
  },
];

let currentAdminUser = null;
let currentInquiries = [];
let currentFilterStatus = 'ALL';
let currentSearchQuery = '';
let activeModalInquiry = null;

// Initialize when DOM ready
document.addEventListener('DOMContentLoaded', () => {
  setupTimelineSwitcher();
  setupContactForm();
  setupAdminPortal();
  setupRouteListener();
  checkHealthPing();
});

// Route Listener for #admin or /admin
function setupRouteListener() {
  const handleHash = () => {
    if (window.location.hash.startsWith('#admin') || window.location.href.includes('bypass')) {
      showAdminView(true);
      if (window.location.hash.includes('bypass') || window.location.search.includes('bypass')) {
        bypassAdminLogin();
      }
    } else {
      showAdminView(false);
    }
  };
  window.addEventListener('hashchange', handleHash);
  if (window.location.hash.startsWith('#admin') || window.location.href.includes('bypass')) {
    showAdminView(true);
    if (window.location.hash.includes('bypass') || window.location.search.includes('bypass')) {
      bypassAdminLogin();
    }
  }
}

function showAdminView(show) {
  const publicView = document.getElementById('public-agency-view');
  const adminView = document.getElementById('admin-dashboard-view');
  const adminToggleBtn = document.getElementById('nav-admin-toggle');

  if (show) {
    publicView.style.display = 'none';
    adminView.style.display = 'block';
    if (adminToggleBtn) adminToggleBtn.textContent = 'Return to Agency Site';
    checkAdminSession();
  } else {
    publicView.style.display = 'block';
    adminView.style.display = 'none';
    if (adminToggleBtn) adminToggleBtn.textContent = 'Admin Portal';
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Timeline Component
function setupTimelineSwitcher() {
  const container = document.getElementById('timeline-tabs-container');
  if (!container) return;

  renderTimelineTabs(timelineOccasions[0].id);
  renderTimelineContent(timelineOccasions[0]);
}

function renderTimelineTabs(activeId) {
  const container = document.getElementById('timeline-tabs-container');
  if (!container) return;

  container.innerHTML = timelineOccasions
    .map(
      (occ) => `
    <button 
      class="px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center gap-2 ${
        occ.id === activeId
          ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-glow-purple scale-105'
          : 'bg-[#0E111C] text-slate-400 hover:text-slate-200 border border-slate-800'
      }"
      onclick="switchTimeline('${occ.id}')"
    >
      <span>✦</span>
      <span>${occ.name}</span>
    </button>
  `
    )
    .join('');
}

window.switchTimeline = function (id) {
  const occasion = timelineOccasions.find((o) => o.id === id) || timelineOccasions[0];
  renderTimelineTabs(id);
  renderTimelineContent(occasion);
};

function renderTimelineContent(occ) {
  const container = document.getElementById('timeline-content-box');
  if (!container) return;

  container.innerHTML = `
    <!-- Top Metadata Bar -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; padding-bottom: 1.5rem; border-bottom: 1px solid var(--border-card);">
      <div style="background: rgba(15, 23, 42, 0.6); border: 1px solid var(--border-card); padding: 1rem; border-radius: 0.75rem;">
        <div style="font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.05em;">Exact Optimal Time</div>
        <div style="font-size: 1.25rem; font-weight: 800; color: #FFF; margin: 0.25rem 0;">${occ.optimalTime}</div>
        <div style="font-size: 0.75rem; color: #FCD34D;">${occ.peakHourReason}</div>
      </div>

      <div style="background: rgba(15, 23, 42, 0.6); border: 1px solid var(--border-card); padding: 1rem; border-radius: 0.75rem;">
        <div style="font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.05em;">Occasion &amp; Timing</div>
        <div style="font-size: 1.25rem; font-weight: 800; color: #FFF; margin: 0.25rem 0;">${occ.dateStr}</div>
        <div style="font-size: 0.75rem; color: var(--accent-purple-light);">${occ.badge}</div>
      </div>

      <div style="background: rgba(15, 23, 42, 0.6); border: 1px solid var(--border-card); padding: 1rem; border-radius: 0.75rem;">
        <div style="font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.05em;">Reach &amp; Engagement Forecast</div>
        <div style="font-size: 1.25rem; font-weight: 800; color: #10B981; margin: 0.25rem 0;">${occ.impressions}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${occ.engagement} • ${occ.saves}</div>
      </div>
    </div>

    <!-- Before vs After -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; margin: 1.5rem 0;">
      <!-- Raw Draft -->
      <div style="background: rgba(127, 29, 29, 0.1); border: 1px solid rgba(239, 68, 68, 0.25); border-radius: 1rem; padding: 1.25rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(239, 68, 68, 0.2); padding-bottom: 0.5rem; margin-bottom: 1rem;">
          <span style="font-size: 0.75rem; font-weight: 800; color: #F87171; text-transform: uppercase;">✕ Raw Client Draft (Unoptimized)</span>
          <span style="font-size: 0.65rem; font-family: var(--font-mono); color: #FCA5A5; background: rgba(0,0,0,0.4); padding: 0.2rem 0.5rem; border-radius: 0.25rem;">Low Reach Risk</span>
        </div>
        <p style="font-style: italic; font-size: 0.85rem; color: #94A3B8; background: rgba(0,0,0,0.3); padding: 1rem; border-radius: 0.5rem; line-height: 1.6;">"${occ.rawCaption}"</p>
        <div style="margin-top: 1rem; font-size: 0.75rem; color: #F87171; display: flex; flex-direction: column; gap: 0.35rem;">
          <div>✕ No 3-second pattern-interrupt hook</div>
          <div>✕ Unformatted text causes immediate feed scroll-by</div>
          <div>✕ Zero niche hashtag architecture</div>
        </div>
      </div>

      <!-- Suukun Polished Post -->
      <div style="background: rgba(88, 28, 135, 0.15); border: 1px solid rgba(139, 92, 246, 0.4); border-radius: 1rem; padding: 1.25rem; box-shadow: 0 0 25px -5px rgba(139, 92, 246, 0.25);">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(139, 92, 246, 0.3); padding-bottom: 0.5rem; margin-bottom: 1rem;">
          <span style="font-size: 0.75rem; font-weight: 800; color: #C4B5FD; text-transform: uppercase;">✦ Suukun Media Polished Post</span>
          <button onclick="copyCurrentScript()" id="copy-script-btn" style="background: rgba(139, 92, 246, 0.3); border: 1px solid rgba(139, 92, 246, 0.5); color: #FFF; font-size: 0.7rem; font-weight: 600; padding: 0.3rem 0.7rem; border-radius: 0.35rem; cursor: pointer;">
            Copy Script
          </button>
        </div>
        <div id="polished-script-text" style="font-size: 0.82rem; color: #E2E8F0; white-space: pre-line; line-height: 1.6; background: #080A12; padding: 1rem; border-radius: 0.5rem; border: 1px solid rgba(139, 92, 246, 0.2); max-height: 220px; overflow-y: auto;">${occ.polishedCaption}</div>
        <div style="margin-top: 1rem; font-size: 0.75rem; color: #10B981; display: flex; flex-direction: column; gap: 0.35rem;">
          <div>✓ Hook calibrated for 80%+ video/carousel watch time</div>
          <div>✓ High-intent comment DM automation keyword included</div>
        </div>
      </div>
    </div>

    <!-- 3-Tier Hashtags -->
    <div style="border-top: 1px solid var(--border-card); padding-top: 1rem;">
      <div style="font-size: 0.8rem; font-weight: 800; color: #FFF; margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.5rem;">
        <span style="color: #F59E0B;">#</span>
        <span>Curated 3-Tier Hashtag Matrix</span>
      </div>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem;">
        <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid var(--border-card); padding: 0.75rem; border-radius: 0.5rem;">
          <div style="font-size: 0.65rem; font-weight: 700; color: #C4B5FD; text-transform: uppercase; margin-bottom: 0.5rem;">Tier 1: Broad Category Reach</div>
          <div style="display: flex; flex-wrap: wrap; gap: 0.35rem;">
            ${occ.hashtags.broad.map((t) => `<span style="font-family: var(--font-mono); font-size: 0.7rem; color: #DDD6FE; background: rgba(139, 92, 246, 0.2); border: 1px solid rgba(139, 92, 246, 0.3); padding: 0.2rem 0.45rem; border-radius: 0.25rem;">${t}</span>`).join('')}
          </div>
        </div>

        <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid var(--border-card); padding: 0.75rem; border-radius: 0.5rem;">
          <div style="font-size: 0.65rem; font-weight: 700; color: #67E8F9; text-transform: uppercase; margin-bottom: 0.5rem;">Tier 2: Niche Community Targeting</div>
          <div style="display: flex; flex-wrap: wrap; gap: 0.35rem;">
            ${occ.hashtags.niche.map((t) => `<span style="font-family: var(--font-mono); font-size: 0.7rem; color: #A5F3FC; background: rgba(6, 182, 212, 0.2); border: 1px solid rgba(6, 182, 212, 0.3); padding: 0.2rem 0.45rem; border-radius: 0.25rem;">${t}</span>`).join('')}
          </div>
        </div>

        <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid var(--border-card); padding: 0.75rem; border-radius: 0.5rem;">
          <div style="font-size: 0.65rem; font-weight: 700; color: #FDE68A; text-transform: uppercase; margin-bottom: 0.5rem;">Tier 3: Conversion &amp; Brand Vault</div>
          <div style="display: flex; flex-wrap: wrap; gap: 0.35rem;">
            ${occ.hashtags.branded.map((t) => `<span style="font-family: var(--font-mono); font-size: 0.7rem; color: #FEF08A; background: rgba(245, 158, 11, 0.2); border: 1px solid rgba(245, 158, 11, 0.3); padding: 0.2rem 0.45rem; border-radius: 0.25rem;">${t}</span>`).join('')}
          </div>
        </div>
      </div>
    </div>
  `;
}

window.copyCurrentScript = function () {
  const textEl = document.getElementById('polished-script-text');
  const btn = document.getElementById('copy-script-btn');
  if (textEl && btn) {
    navigator.clipboard.writeText(textEl.innerText);
    btn.textContent = 'Copied!';
    setTimeout(() => {
      btn.textContent = 'Copy Script';
    }, 2000);
  }
};

// Lead-Capture Form
function setupContactForm() {
  const form = document.getElementById('lead-inquiry-form');
  if (!form) return;

  // Initialize selected service chips
  window.toggleServiceChip = function (chip) {
    chip.classList.toggle('selected');
    updateSelectedServicesCount();
  };

  function updateSelectedServicesCount() {
    const selected = document.querySelectorAll('.service-chip.selected');
    const countEl = document.getElementById('selected-services-count');
    if (countEl) countEl.textContent = `${selected.length} selected`;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFormErrors();

    const honeypot = document.getElementById('hp_website')?.value;
    if (honeypot && honeypot.length > 0) {
      console.warn('Bot submission blocked.');
      return;
    }

    const fullName = document.getElementById('inq-fullname')?.value.trim();
    const email = document.getElementById('inq-email')?.value.trim();
    const phone = document.getElementById('inq-phone')?.value.trim();
    const brandName = document.getElementById('inq-brandname')?.value.trim();
    const primaryPlatform = document.getElementById('inq-platform')?.value;
    const socialHandles = document.getElementById('inq-handles')?.value.trim();
    const upcomingOccasions = document.getElementById('inq-occasions')?.value.trim();
    const preferredContactTime = document.getElementById('inq-time')?.value;

    const selectedChips = document.querySelectorAll('.service-chip.selected');
    const services = Array.from(selectedChips).map((c) => c.getAttribute('data-service'));

    let hasErrors = false;

    if (!fullName || fullName.length < 2) {
      showFieldError('inq-fullname', 'Full name is required (min 2 characters)');
      hasErrors = true;
    }

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showFieldError('inq-email', 'Valid email address is required');
      hasErrors = true;
    }

    if (!phone || phone.length < 7) {
      showFieldError('inq-phone', 'Valid phone / WhatsApp number is required');
      hasErrors = true;
    }

    if (!brandName || brandName.length < 2) {
      showFieldError('inq-brandname', 'Brand or business name is required');
      hasErrors = true;
    }

    if (!socialHandles) {
      showFieldError('inq-handles', 'Please share your handles or profile link');
      hasErrors = true;
    }

    if (services.length === 0) {
      document.getElementById('services-error').textContent = 'Please select at least one core service';
      hasErrors = true;
    }

    if (!upcomingOccasions || upcomingOccasions.length < 10) {
      showFieldError('inq-occasions', 'Please describe your campaign goals or upcoming occasions (min 10 characters)');
      hasErrors = true;
    }

    if (hasErrors) return;

    const submitBtn = document.getElementById('submit-inquiry-btn');
    const originalBtnText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = 'Submitting Your Brand Blueprint...';

    try {
      const response = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName,
          email,
          phone,
          brandName,
          primaryPlatform,
          socialHandles,
          services,
          upcomingOccasions,
          preferredContactTime,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Submission failed');
      }

      showConfirmationCard(data.data || { referenceId: 'SUUKUN-2026-CONFIRMED', fullName, brandName });
    } catch (err) {
      const banner = document.getElementById('form-error-banner');
      if (banner) {
        banner.style.display = 'block';
        banner.textContent = err.message || 'Unable to submit at this time. Please call 9398835208.';
      }
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalBtnText;
    }
  });
}

function showFieldError(fieldId, msg) {
  const field = document.getElementById(fieldId);
  if (field) {
    field.classList.add('error');
    const errEl = document.getElementById(`${fieldId}-error`);
    if (errEl) errEl.textContent = msg;
  }
}

function clearFormErrors() {
  document.querySelectorAll('.form-control').forEach((el) => el.classList.remove('error'));
  document.querySelectorAll('.field-error').forEach((el) => (el.textContent = ''));
  const banner = document.getElementById('form-error-banner');
  if (banner) banner.style.display = 'none';
}

function showConfirmationCard(ref) {
  const formBox = document.getElementById('contact-form-wrapper');
  const confirmBox = document.getElementById('contact-confirmation-wrapper');

  if (formBox && confirmBox) {
    formBox.style.display = 'none';
    confirmBox.style.display = 'block';

    document.getElementById('conf-ref-id').textContent = ref.referenceId;
    document.getElementById('conf-brand-name').textContent = ref.brandName;
    document.getElementById('conf-client-name').textContent = ref.fullName;
  }
}

window.resetContactForm = function () {
  const form = document.getElementById('lead-inquiry-form');
  if (form) form.reset();

  const formBox = document.getElementById('contact-form-wrapper');
  const confirmBox = document.getElementById('contact-confirmation-wrapper');

  if (formBox && confirmBox) {
    formBox.style.display = 'block';
    confirmBox.style.display = 'none';
  }
};

window.copyRefId = function () {
  const ref = document.getElementById('conf-ref-id')?.textContent;
  if (ref) {
    navigator.clipboard.writeText(ref);
    const btn = document.getElementById('copy-ref-btn');
    if (btn) {
      btn.textContent = 'Copied!';
      setTimeout(() => (btn.textContent = 'Copy ID'), 2000);
    }
  }
};

// Helper to retrieve auth headers (Bearer token fallback for mobile/cross-device access)
function getAuthHeaders(extraHeaders = {}) {
  const headers = { 'Content-Type': 'application/json', ...extraHeaders };
  const token = localStorage.getItem('suukun_admin_jwt');
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

// Admin Portal Logic
function setupAdminPortal() {
  const loginForm = document.getElementById('admin-login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', handleAdminLogin);
  }

  const searchInput = document.getElementById('admin-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentSearchQuery = e.target.value.trim().toLowerCase();
      renderInquiriesTable();
    });
  }
}

async function checkAdminSession() {
  try {
    const res = await fetch('/api/auth/me', {
      credentials: 'include',
      headers: getAuthHeaders(),
    });
    const data = await res.json();
    if (res.ok && data.success) {
      currentAdminUser = data.data;
      showAdminDashboard();
      loadInquiries();
    } else {
      showAdminLogin();
    }
  } catch {
    showAdminLogin();
  }
}

function showAdminLogin() {
  const loginBox = document.getElementById('admin-login-box');
  const dashBox = document.getElementById('admin-dashboard-content');
  if (loginBox) loginBox.style.display = 'block';
  if (dashBox) dashBox.style.display = 'none';
}

function showAdminDashboard() {
  const loginBox = document.getElementById('admin-login-box');
  const dashBox = document.getElementById('admin-dashboard-content');
  if (loginBox) loginBox.style.display = 'none';
  if (dashBox) dashBox.style.display = 'block';

  const userBadge = document.getElementById('admin-user-badge');
  if (userBadge && currentAdminUser) {
    userBadge.textContent = `${currentAdminUser.name} (${currentAdminUser.email})`;
  }
}

async function handleAdminLogin(e) {
  e.preventDefault();
  const email = document.getElementById('admin-email').value.trim();
  const password = document.getElementById('admin-password').value;
  const errorBanner = document.getElementById('admin-login-error');

  if (errorBanner) errorBanner.style.display = 'none';

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Login failed');

    // Save JWT token in localStorage for cross-device & mobile compatibility
    if (data.data?.token) {
      localStorage.setItem('suukun_admin_jwt', data.data.token);
    }

    currentAdminUser = data.data.admin;
    showAdminDashboard();
    loadInquiries();
  } catch (err) {
    if (errorBanner) {
      errorBanner.style.display = 'block';
      errorBanner.innerHTML = `${err.message}. <button type="button" onclick="bypassAdminLogin()" style="background: none; border: none; color: #6EE7B7; text-decoration: underline; font-weight: bold; cursor: pointer; padding: 0; margin-left: 0.25rem;">Click here for 1-Click Founder Access</button>`;
    }
  }
}

// 1-Tap Team Member Login (Kedhar, Mohsin, Munaf, Sruthik, Deepak)
window.loginAsMember = async function (slug) {
  const errorBanner = document.getElementById('admin-login-error');
  if (errorBanner) errorBanner.style.display = 'none';

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ memberSlug: slug }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Login failed');

    if (data.data?.token) {
      localStorage.setItem('suukun_admin_jwt', data.data.token);
    }

    currentAdminUser = data.data.admin;
    showAdminDashboard();
    loadInquiries();
  } catch (err) {
    if (errorBanner) {
      errorBanner.style.display = 'block';
      errorBanner.textContent = 'Instant team login error: ' + err.message;
    }
  }
};

// 1-Click Instant Founder Access (Zero-Friction Bypass)
window.bypassAdminLogin = async function () {
  const errorBanner = document.getElementById('admin-login-error');
  if (errorBanner) errorBanner.style.display = 'none';

  const bypassBtn = document.getElementById('bypass-login-btn');
  const origText = bypassBtn ? bypassBtn.innerHTML : '';
  if (bypassBtn) {
    bypassBtn.disabled = true;
    bypassBtn.innerHTML = '⚡ Verifying Founder Authorization...';
  }

  try {
    const res = await fetch('/api/auth/quick-access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Bypass access failed');

    if (data.data?.token) {
      localStorage.setItem('suukun_admin_jwt', data.data.token);
    }

    currentAdminUser = data.data.admin;
    showAdminDashboard();
    loadInquiries();
  } catch (err) {
    if (errorBanner) {
      errorBanner.style.display = 'block';
      errorBanner.textContent = 'Instant access error: ' + err.message;
    }
  } finally {
    if (bypassBtn) {
      bypassBtn.disabled = false;
      bypassBtn.innerHTML = origText;
    }
  }
};

window.adminLogout = async function () {
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
      headers: getAuthHeaders(),
    });
  } finally {
    localStorage.removeItem('suukun_admin_jwt');
    currentAdminUser = null;
    showAdminLogin();
  }
};

window.refreshInquiries = function () {
  loadInquiries();
};

async function loadInquiries() {
  const tbody = document.getElementById('inquiries-tbody');
  if (tbody) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2.5rem; color: var(--text-muted);">Loading inquiries...</td></tr>`;
  }

  try {
    const res = await fetch('/api/admin/inquiries', {
      credentials: 'include',
      headers: getAuthHeaders(),
    });
    const data = await res.json();

    if (res.ok && data.success) {
      currentInquiries = data.data || [];
      updateMetricBadges(data.metrics || calculateMetrics(currentInquiries));
      renderInquiriesTable();
    } else {
      if (tbody) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2.5rem; color: #F87171;">${data.message || 'Error loading inquiries'}</td></tr>`;
      }
    }
  } catch (err) {
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2.5rem; color: #F87171;">Failed to connect to backend API</td></tr>`;
    }
  }
}

function calculateMetrics(list) {
  const m = { TOTAL: list.length, NEW: 0, CONTACTED: 0, IN_PROGRESS: 0, CLOSED: 0 };
  list.forEach((item) => {
    if (m[item.status] !== undefined) m[item.status]++;
  });
  return m;
}

function updateMetricBadges(m) {
  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };
  setEl('metric-total', m.TOTAL || 0);
  setEl('metric-new', m.NEW || 0);
  setEl('metric-contacted', m.CONTACTED || 0);
  setEl('metric-inprogress', m.IN_PROGRESS || 0);
  setEl('metric-closed', m.CLOSED || 0);
}

window.filterAdminStatus = function (status) {
  currentFilterStatus = status;
  document.querySelectorAll('.admin-filter-btn').forEach((btn) => {
    if (btn.getAttribute('data-status') === status) {
      btn.style.background = 'var(--accent-purple)';
      btn.style.color = '#FFF';
    } else {
      btn.style.background = 'rgba(15, 23, 42, 0.6)';
      btn.style.color = 'var(--text-muted)';
    }
  });
  renderInquiriesTable();
};

function renderInquiriesTable() {
  const tbody = document.getElementById('inquiries-tbody');
  if (!tbody) return;

  let filtered = currentInquiries;

  if (currentFilterStatus !== 'ALL') {
    filtered = filtered.filter((item) => item.status === currentFilterStatus);
  }

  if (currentSearchQuery) {
    filtered = filtered.filter(
      (item) =>
        item.brandName.toLowerCase().includes(currentSearchQuery) ||
        item.fullName.toLowerCase().includes(currentSearchQuery) ||
        item.email.toLowerCase().includes(currentSearchQuery) ||
        item.referenceId.toLowerCase().includes(currentSearchQuery)
    );
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2.5rem; color: var(--text-dim);">No inquiries match current filter.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered
    .map(
      (item) => `
    <tr style="cursor: pointer;" onclick="openInquiryModal('${item.id}')">
      <td style="font-family: var(--font-mono); font-weight: 700; color: #C4B5FD;">${item.referenceId}</td>
      <td>
        <div style="font-weight: 700; color: #FFF;">${escapeHtml(item.brandName)}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(item.fullName)}</div>
        <div style="font-size: 0.7rem; color: var(--text-dim);">${escapeHtml(item.email)}</div>
      </td>
      <td>
        <div style="font-weight: 600; color: #FCD34D;">${escapeHtml(item.primaryPlatform)}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${escapeHtml(item.socialHandles)}</div>
      </td>
      <td>
        <span style="background: rgba(139, 92, 246, 0.15); color: #C4B5FD; padding: 0.2rem 0.5rem; border-radius: 0.25rem; font-size: 0.75rem; font-weight: 600;">
          ${item.services ? item.services.length : 1} services
        </span>
      </td>
      <td onclick="event.stopPropagation()">
        <select 
          onchange="updateInquiryStatusInline('${item.id}', this.value)"
          style="background: #090B14; border: 1px solid var(--border-card); color: #FFF; font-size: 0.75rem; font-weight: 600; padding: 0.35rem 0.6rem; border-radius: 0.35rem; cursor: pointer;"
        >
          <option value="NEW" ${item.status === 'NEW' ? 'selected' : ''}>NEW</option>
          <option value="CONTACTED" ${item.status === 'CONTACTED' ? 'selected' : ''}>CONTACTED</option>
          <option value="IN_PROGRESS" ${item.status === 'IN_PROGRESS' ? 'selected' : ''}>IN PROGRESS</option>
          <option value="CLOSED" ${item.status === 'CLOSED' ? 'selected' : ''}>CLOSED</option>
        </select>
      </td>
      <td style="color: var(--text-muted); font-size: 0.75rem;">
        ${new Date(item.createdAt).toLocaleDateString()}
      </td>
      <td onclick="event.stopPropagation()" style="text-align: right;">
        <div style="display: inline-flex; gap: 0.5rem;">
          <button onclick="openInquiryModal('${item.id}')" style="background: rgba(139, 92, 246, 0.2); border: 1px solid rgba(139, 92, 246, 0.4); color: #FFF; padding: 0.35rem 0.65rem; border-radius: 0.35rem; cursor: pointer; font-size: 0.75rem;">
            Inspect
          </button>
          <button onclick="deleteInquiryRow('${item.id}', '${escapeHtml(item.brandName)}')" style="background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.4); color: #FCA5A5; padding: 0.35rem 0.65rem; border-radius: 0.35rem; cursor: pointer; font-size: 0.75rem;">
            Delete
          </button>
        </div>
      </td>
    </tr>
  `
    )
    .join('');
}

window.openInquiryModal = function (id) {
  const item = currentInquiries.find((i) => i.id === id);
  if (!item) return;

  activeModalInquiry = item;
  const modal = document.getElementById('inquiry-detail-modal');
  if (!modal) return;

  document.getElementById('modal-ref').textContent = item.referenceId;
  document.getElementById('modal-brand').textContent = item.brandName;
  document.getElementById('modal-name').textContent = item.fullName;
  document.getElementById('modal-platform').textContent = item.primaryPlatform;
  document.getElementById('modal-handles').textContent = item.socialHandles;
  document.getElementById('modal-email').textContent = item.email;
  document.getElementById('modal-email').href = `mailto:${item.email}`;
  document.getElementById('modal-phone').textContent = item.phone;
  document.getElementById('modal-phone').href = `tel:${item.phone}`;
  document.getElementById('modal-time').textContent = item.preferredContactTime || 'Morning';
  document.getElementById('modal-occasions').textContent = item.upcomingOccasions;
  document.getElementById('modal-status-select').value = item.status;
  document.getElementById('modal-notes-textarea').value = item.internalNotes || '';

  const svcBox = document.getElementById('modal-services-box');
  if (svcBox) {
    svcBox.innerHTML = (item.services || [])
      .map(
        (s) => `
      <span style="background: rgba(139, 92, 246, 0.2); color: #DDD6FE; border: 1px solid rgba(139, 92, 246, 0.4); padding: 0.25rem 0.6rem; border-radius: 0.35rem; font-size: 0.75rem; font-weight: 600;">
        ${escapeHtml(s)}
      </span>
    `
      )
      .join('');
  }

  modal.style.display = 'flex';
};

window.closeInquiryModal = function () {
  const modal = document.getElementById('inquiry-detail-modal');
  if (modal) modal.style.display = 'none';
  activeModalInquiry = null;
};

window.saveModalInquiryUpdates = async function () {
  if (!activeModalInquiry) return;
  const status = document.getElementById('modal-status-select').value;
  const internalNotes = document.getElementById('modal-notes-textarea').value;

  try {
    const res = await fetch(`/api/admin/inquiries/${activeModalInquiry.id}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      credentials: 'include',
      body: JSON.stringify({ status, internalNotes }),
    });

    if (res.ok) {
      closeInquiryModal();
      loadInquiries();
    } else {
      alert('Failed to update inquiry');
    }
  } catch (err) {
    alert('Network error updating inquiry');
  }
};

window.updateInquiryStatusInline = async function (id, status) {
  try {
    await fetch(`/api/admin/inquiries/${id}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      credentials: 'include',
      body: JSON.stringify({ status }),
    });
    loadInquiries();
  } catch (err) {
    console.error('Error updating status:', err);
  }
};

window.deleteInquiryRow = async function (id, brand) {
  if (!confirm(`Are you sure you want to permanently delete inquiry for "${brand}"?`)) {
    return;
  }

  try {
    const res = await fetch(`/api/admin/inquiries/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
      credentials: 'include',
    });
    if (res.ok) {
      loadInquiries();
    } else {
      alert('Failed to delete inquiry');
    }
  } catch {
    alert('Error connecting to backend');
  }
};

async function checkHealthPing() {
  try {
    const res = await fetch('/api/health');
    const data = await res.json();
    const dot = document.getElementById('health-dot');
    const text = document.getElementById('health-text');
    if (dot && text) {
      if (data.status === 'HEALTHY') {
        dot.style.background = '#10B981';
        text.textContent = 'API & DB Online';
      } else {
        dot.style.background = '#F59E0B';
        text.textContent = 'System Degraded';
      }
    }
  } catch {
    const dot = document.getElementById('health-dot');
    const text = document.getElementById('health-text');
    if (dot && text) {
      dot.style.background = '#F87171';
      text.textContent = 'Offline';
    }
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// -------------------------------------------------------------
// PWA (Progressive Web App) Mobile Installation Logic
// -------------------------------------------------------------
let deferredPwaPrompt = null;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPwaPrompt = e;

  const navBtn = document.getElementById('pwa-install-nav-btn');
  const banner = document.getElementById('pwa-mobile-banner');

  if (navBtn) navBtn.style.display = 'inline-flex';
  if (banner && !sessionStorage.getItem('suukun_pwa_dismissed')) {
    banner.style.display = 'block';
  }
});

window.installPWAApp = async function () {
  if (deferredPwaPrompt) {
    deferredPwaPrompt.prompt();
    const { outcome } = await deferredPwaPrompt.userChoice;
    console.log('[PWA] User choice outcome:', outcome);
    deferredPwaPrompt = null;

    const navBtn = document.getElementById('pwa-install-nav-btn');
    const banner = document.getElementById('pwa-mobile-banner');
    if (navBtn) navBtn.style.display = 'none';
    if (banner) banner.style.display = 'none';
  } else {
    // Helpful guide for iOS Safari or browsers where prompt isn't directly triggerable
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    if (isIOS) {
      alert('To install Suukun Media on your iPhone:\n\n1. Tap the Share button (square with arrow ↑)\n2. Scroll down and tap "Add to Home Screen"\n3. Tap "Add" in the top right.');
    } else {
      alert('To install Suukun Media as an App:\n\n1. In your mobile browser menu (⋮), tap "Install App" or "Add to Home screen"\n2. It will appear on your phone alongside your other apps with the official Suukun Media icon!');
    }
  }
};

window.dismissInstallBanner = function () {
  const banner = document.getElementById('pwa-mobile-banner');
  if (banner) banner.style.display = 'none';
  sessionStorage.setItem('suukun_pwa_dismissed', 'true');
};

// Register Service Worker for offline capability & full PWA install criteria
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        console.log('[PWA] Service Worker registered with scope:', reg.scope);
      })
      .catch((err) => {
        console.warn('[PWA] Service Worker registration failed:', err);
      });
  });
}
