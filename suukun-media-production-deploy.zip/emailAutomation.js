/**
 * Suukun Media - Zero-Dependency Email & Automated Re-mailing Engine
 * Strict Zero-Google Compliance: Uses native Node.js net/tls SMTP or standard HTTPS APIs.
 */

const net = require('net');
const tls = require('tls');
const crypto = require('crypto');

const DEFAULT_AUTO_REPLY_SUBJECT = 'Your Suukun Media Brand Blueprint Request ({{referenceId}})';
const DEFAULT_AUTO_REPLY_BODY = `Hi {{fullName}},

Thank you for reaching out to Suukun Media regarding {{brandName}}!

We have received your Brand Blueprint request for {{platform}} ({{services}}).
Your Reference ID is: {{referenceId}}

What happens next:
1. Our creative & growth operations desk is reviewing your handles and upcoming occasions.
2. We will reach out during your preferred slot ({{contactTime}}) within 24 hours with a tailored occasion timeline and reach strategy.

For priority assistance, reply directly or call us at +91 9398835208 citing {{referenceId}}.

Best regards,
Suukun Media Strategy Desk
https://suukun-media.onrender.com`;

const DEFAULT_REMAIL_SUBJECT = 'Follow-up: Custom Growth & Occasion Strategy for {{brandName}} ({{referenceId}})';
const DEFAULT_REMAIL_BODY = `Hi {{fullName}},

Checking back in regarding your brand growth inquiry for {{brandName}} (Ref: {{referenceId}}).

Our strategy team has outlined initial ideas for your {{platform}} presence, covering {{services}} aligned with your upcoming campaign occasions.

Would you like us to walk you through the custom posting calendar and reach blueprint during your preferred window ({{contactTime}})? Simply reply to this email with a good time or reach us at +91 9398835208.

Warm regards,
Suukun Media Team
create • grow • inspire`;

function initEmailSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS email_settings (
      id TEXT PRIMARY KEY,
      provider TEXT DEFAULT 'NONE',
      smtp_host TEXT DEFAULT '',
      smtp_port INTEGER DEFAULT 587,
      smtp_secure INTEGER DEFAULT 0,
      smtp_user TEXT DEFAULT '',
      smtp_pass TEXT DEFAULT '',
      api_url TEXT DEFAULT '',
      api_key TEXT DEFAULT '',
      from_name TEXT DEFAULT 'Suukun Media',
      from_email TEXT DEFAULT '',
      admin_notify_email TEXT DEFAULT '',
      auto_reply_enabled INTEGER DEFAULT 1,
      admin_alert_enabled INTEGER DEFAULT 1,
      remail_enabled INTEGER DEFAULT 1,
      remail_delay_hours INTEGER DEFAULT 24,
      remail_max_attempts INTEGER DEFAULT 2,
      auto_reply_subject TEXT DEFAULT '',
      auto_reply_template TEXT DEFAULT '',
      remail_subject TEXT DEFAULT '',
      remail_template TEXT DEFAULT '',
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS email_logs (
      id TEXT PRIMARY KEY,
      inquiry_id TEXT,
      recipient_email TEXT NOT NULL,
      subject TEXT NOT NULL,
      body TEXT NOT NULL,
      email_type TEXT NOT NULL,
      status TEXT NOT NULL,
      provider_response TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Safely extend existing inquiries table for re-mail tracking
  const alterStatements = [
    'ALTER TABLE inquiries ADD COLUMN remail_count INTEGER DEFAULT 0',
    'ALTER TABLE inquiries ADD COLUMN last_emailed_at TEXT',
    'ALTER TABLE inquiries ADD COLUMN remail_paused INTEGER DEFAULT 0',
  ];
  for (const sql of alterStatements) {
    try {
      db.exec(sql);
    } catch {
      // Column already exists
    }
  }

  // Seed default configuration if absent (respects optional environment variables)
  const existing = db.prepare('SELECT id FROM email_settings WHERE id = ?').get('default');
  if (!existing) {
    const envProvider = process.env.EMAIL_API_KEY
      ? 'HTTPS_API'
      : process.env.SMTP_HOST
        ? 'SMTP'
        : 'NONE';

    db.prepare(`
      INSERT INTO email_settings (
        id, provider, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass,
        api_url, api_key, from_name, from_email, admin_notify_email,
        auto_reply_enabled, admin_alert_enabled, remail_enabled,
        remail_delay_hours, remail_max_attempts,
        auto_reply_subject, auto_reply_template, remail_subject, remail_template
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 1, 24, 2, ?, ?, ?, ?)
    `).run(
      'default',
      envProvider,
      process.env.SMTP_HOST || '',
      Number(process.env.SMTP_PORT || 587),
      process.env.SMTP_SECURE === 'true' ? 1 : 0,
      process.env.SMTP_USER || '',
      process.env.SMTP_PASS || '',
      process.env.EMAIL_API_URL || 'https://api.resend.com/emails',
      process.env.EMAIL_API_KEY || '',
      process.env.EMAIL_FROM_NAME || 'Suukun Media',
      process.env.EMAIL_FROM || process.env.SMTP_USER || '',
      process.env.ADMIN_NOTIFY_EMAIL || '',
      DEFAULT_AUTO_REPLY_SUBJECT,
      DEFAULT_AUTO_REPLY_BODY,
      DEFAULT_REMAIL_SUBJECT,
      DEFAULT_REMAIL_BODY
    );
  }
}

function getRawSettings(db) {
  return db.prepare('SELECT * FROM email_settings WHERE id = ?').get('default');
}

function getMaskedSettings(db) {
  const row = getRawSettings(db);
  if (!row) return null;
  return {
    provider: row.provider,
    smtpHost: row.smtp_host,
    smtpPort: row.smtp_port,
    smtpSecure: Boolean(row.smtp_secure),
    smtpUser: row.smtp_user,
    smtpPassConfigured: Boolean(row.smtp_pass && row.smtp_pass.length > 0),
    apiUrl: row.api_url,
    apiKeyConfigured: Boolean(row.api_key && row.api_key.length > 0),
    fromName: row.from_name,
    fromEmail: row.from_email,
    adminNotifyEmail: row.admin_notify_email,
    autoReplyEnabled: Boolean(row.auto_reply_enabled),
    adminAlertEnabled: Boolean(row.admin_alert_enabled),
    remailEnabled: Boolean(row.remail_enabled),
    remailDelayHours: row.remail_delay_hours,
    remailMaxAttempts: row.remail_max_attempts,
    autoReplySubject: row.auto_reply_subject,
    autoReplyTemplate: row.auto_reply_template,
    remailSubject: row.remail_subject,
    remailTemplate: row.remail_template,
    updatedAt: row.updated_at,
  };
}

function updateEmailSettings(db, data) {
  const current = getRawSettings(db);
  const nextSmtpPass = data.smtpPass && data.smtpPass.trim() !== '' ? data.smtpPass.trim() : current.smtp_pass;
  const nextApiKey = data.apiKey && data.apiKey.trim() !== '' ? data.apiKey.trim() : current.api_key;

  const allowedProviders = ['NONE', 'SMTP', 'HTTPS_API'];
  const provider = allowedProviders.includes(data.provider) ? data.provider : current.provider;

  db.prepare(`
    UPDATE email_settings SET
      provider = ?,
      smtp_host = ?,
      smtp_port = ?,
      smtp_secure = ?,
      smtp_user = ?,
      smtp_pass = ?,
      api_url = ?,
      api_key = ?,
      from_name = ?,
      from_email = ?,
      admin_notify_email = ?,
      auto_reply_enabled = ?,
      admin_alert_enabled = ?,
      remail_enabled = ?,
      remail_delay_hours = ?,
      remail_max_attempts = ?,
      auto_reply_subject = ?,
      auto_reply_template = ?,
      remail_subject = ?,
      remail_template = ?,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = 'default'
  `).run(
    provider,
    (data.smtpHost ?? current.smtp_host).trim(),
    Math.max(1, Math.min(65535, Number(data.smtpPort ?? current.smtp_port) || 587)),
    data.smtpSecure !== undefined ? (data.smtpSecure ? 1 : 0) : current.smtp_secure,
    (data.smtpUser ?? current.smtp_user).trim(),
    nextSmtpPass,
    (data.apiUrl ?? current.api_url).trim(),
    nextApiKey,
    (data.fromName ?? current.from_name).trim() || 'Suukun Media',
    (data.fromEmail ?? current.from_email).trim(),
    (data.adminNotifyEmail ?? current.admin_notify_email).trim(),
    data.autoReplyEnabled !== undefined ? (data.autoReplyEnabled ? 1 : 0) : current.auto_reply_enabled,
    data.adminAlertEnabled !== undefined ? (data.adminAlertEnabled ? 1 : 0) : current.admin_alert_enabled,
    data.remailEnabled !== undefined ? (data.remailEnabled ? 1 : 0) : current.remail_enabled,
    Math.max(1, Math.min(720, Number(data.remailDelayHours ?? current.remail_delay_hours) || 24)),
    Math.max(1, Math.min(10, Number(data.remailMaxAttempts ?? current.remail_max_attempts) || 2)),
    (data.autoReplySubject ?? current.auto_reply_subject).trim() || DEFAULT_AUTO_REPLY_SUBJECT,
    (data.autoReplyTemplate ?? current.auto_reply_template).trim() || DEFAULT_AUTO_REPLY_BODY,
    (data.remailSubject ?? current.remail_subject).trim() || DEFAULT_REMAIL_SUBJECT,
    (data.remailTemplate ?? current.remail_template).trim() || DEFAULT_REMAIL_BODY
  );

  return getMaskedSettings(db);
}

function renderTemplate(template, vars) {
  return String(template || '').replace(/\{\{(\w+)\}\}/g, (_, key) => {
    return vars[key] !== undefined && vars[key] !== null ? String(vars[key]) : '';
  });
}

function escapeSmtpHeader(str) {
  return String(str || '').replace(/[\r\n]+/g, ' ').trim();
}

function sendViaSmtp(cfg, { to, subject, text }) {
  return new Promise((resolve, reject) => {
    const host = cfg.smtp_host;
    const port = Number(cfg.smtp_port) || 587;
    const useDirectTls = Boolean(cfg.smtp_secure) || port === 465;
    const user = cfg.smtp_user;
    const pass = cfg.smtp_pass;
    const fromEmail = cfg.from_email || user;
    const fromHeader = `${escapeSmtpHeader(cfg.from_name || 'Suukun Media')} <${escapeSmtpHeader(fromEmail)}>`;

    if (!host || !user || !pass || !fromEmail) {
      return reject(new Error('Incomplete SMTP host, user, password, or sender email configuration.'));
    }

    let socket;
    let buffer = '';
    let step = 'GREETING';
    let finished = false;

    const fail = (err) => {
      if (finished) return;
      finished = true;
      try { socket?.destroy(); } catch {}
      reject(err instanceof Error ? err : new Error(String(err)));
    };

    const done = (msg) => {
      if (finished) return;
      finished = true;
      try { socket?.end(); } catch {}
      resolve(msg);
    };

    const writeLine = (line) => {
      socket.write(line + '\r\n');
    };

    const handleLine = (code, fullLine) => {
      if (code >= 400) {
        return fail(new Error(`SMTP ${step} error (${code}): ${fullLine}`));
      }

      if (step === 'GREETING' && code === 220) {
        step = 'EHLO_INIT';
        writeLine(`EHLO ${host}`);
      } else if (step === 'EHLO_INIT' && code === 250) {
        if (!useDirectTls && fullLine.toUpperCase().includes('STARTTLS')) {
          step = 'STARTTLS';
          writeLine('STARTTLS');
        } else {
          step = 'AUTH_LOGIN';
          writeLine('AUTH LOGIN');
        }
      } else if (step === 'STARTTLS' && code === 220) {
        const plainSocket = socket;
        plainSocket.removeAllListeners('data');
        socket = tls.connect({ socket: plainSocket, servername: host }, () => {
          buffer = '';
          step = 'EHLO_TLS';
          attachSocketEvents(socket);
          writeLine(`EHLO ${host}`);
        });
        socket.setTimeout(15000, () => fail(new Error('SMTP TLS handshake timeout')));
        socket.on('error', fail);
      } else if (step === 'EHLO_TLS' && code === 250) {
        step = 'AUTH_LOGIN';
        writeLine('AUTH LOGIN');
      } else if (step === 'AUTH_LOGIN' && code === 334) {
        step = 'AUTH_USER';
        writeLine(Buffer.from(user).toString('base64'));
      } else if (step === 'AUTH_USER' && code === 334) {
        step = 'AUTH_PASS';
        writeLine(Buffer.from(pass).toString('base64'));
      } else if (step === 'AUTH_PASS' && code === 235) {
        step = 'MAIL_FROM';
        writeLine(`MAIL FROM:<${escapeSmtpHeader(fromEmail)}>`);
      } else if (step === 'MAIL_FROM' && code === 250) {
        step = 'RCPT_TO';
        writeLine(`RCPT TO:<${escapeSmtpHeader(to)}>`);
      } else if (step === 'RCPT_TO' && (code === 250 || code === 251)) {
        step = 'DATA_CMD';
        writeLine('DATA');
      } else if (step === 'DATA_CMD' && code === 354) {
        step = 'DATA_BODY';
        const messageId = `<${crypto.randomUUID()}@${host}>`;
        const safeText = String(text || '').replace(/\r?\n/g, '\r\n').replace(/^\./gm, '..');
        const rawEmail = [
          `From: ${fromHeader}`,
          `To: <${escapeSmtpHeader(to)}>`,
          `Subject: ${escapeSmtpHeader(subject)}`,
          `Message-ID: ${messageId}`,
          `Date: ${new Date().toUTCString()}`,
          'MIME-Version: 1.0',
          'Content-Type: text/plain; charset=UTF-8',
          '',
          safeText,
          '.',
        ].join('\r\n');
        socket.write(rawEmail + '\r\n');
      } else if (step === 'DATA_BODY' && code === 250) {
        step = 'QUIT';
        writeLine('QUIT');
        done(`SMTP accepted (${fullLine.trim()})`);
      }
    };

    const attachSocketEvents = (sock) => {
      let multiLineAcc = '';
      sock.on('data', (chunk) => {
        buffer += chunk.toString('utf8');
        let idx;
        while ((idx = buffer.indexOf('\n')) !== -1) {
          const line = buffer.slice(0, idx).replace(/\r$/, '');
          buffer = buffer.slice(idx + 1);
          if (!line) continue;
          multiLineAcc += (multiLineAcc ? '\n' : '') + line;
          // Standard SMTP final line has a space after the 3-digit status code
          if (/^\d{3} /.test(line)) {
            const code = parseInt(line.slice(0, 3), 10);
            const full = multiLineAcc;
            multiLineAcc = '';
            handleLine(code, full);
          }
        }
      });
      sock.on('error', fail);
      sock.on('timeout', () => fail(new Error('SMTP connection timed out')));
    };

    socket = useDirectTls
      ? tls.connect({ host, port, servername: host })
      : net.connect({ host, port });

    socket.setTimeout(15000);
    attachSocketEvents(socket);
  });
}

async function sendViaHttpsApi(cfg, { to, subject, text }) {
  const url = cfg.api_url;
  const apiKey = cfg.api_key;
  const fromEmail = cfg.from_email;
  const fromName = cfg.from_name || 'Suukun Media';

  if (!url || !fromEmail) {
    throw new Error('Email API URL and Sender Email are required for HTTPS API mode.');
  }

  let payload;
  const headers = { 'Content-Type': 'application/json' };

  if (url.includes('brevo.com')) {
    if (apiKey) headers['api-key'] = apiKey;
    payload = {
      sender: { name: fromName, email: fromEmail },
      to: [{ email: to }],
      subject,
      textContent: text,
    };
  } else {
    // Standard Resend / compatible JSON webhook payload
    if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
    payload = {
      from: `${fromName} <${fromEmail}>`,
      to: [to],
      subject,
      text,
    };
  }

  const res = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });

  const bodyText = await res.text();
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: ${bodyText.slice(0, 300)}`);
  }

  return `HTTPS API ${res.status}: ${bodyText.slice(0, 200)}`;
}

async function dispatchEmail(db, { inquiryId = null, to, subject, text, emailType }) {
  const cfg = getRawSettings(db);
  const logId = crypto.randomUUID();

  let status = 'QUEUED_NO_TRANSPORT';
  let providerResponse = 'Saved to outbox log (configure SMTP or HTTPS Email API in Admin Settings for external delivery).';

  if (cfg && cfg.provider === 'SMTP') {
    try {
      providerResponse = await sendViaSmtp(cfg, { to, subject, text });
      status = 'SENT';
    } catch (err) {
      status = 'FAILED';
      providerResponse = err.message;
    }
  } else if (cfg && cfg.provider === 'HTTPS_API') {
    try {
      providerResponse = await sendViaHttpsApi(cfg, { to, subject, text });
      status = 'SENT';
    } catch (err) {
      status = 'FAILED';
      providerResponse = err.message;
    }
  }

  db.prepare(`
    INSERT INTO email_logs (id, inquiry_id, recipient_email, subject, body, email_type, status, provider_response)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(logId, inquiryId, to, subject, text, emailType, status, providerResponse);

  return { id: logId, to, subject, emailType, status, providerResponse };
}

function buildInquiryVars(inquiry) {
  let servicesList = [];
  try {
    servicesList = typeof inquiry.services === 'string' ? JSON.parse(inquiry.services) : inquiry.services || [];
  } catch {
    servicesList = [String(inquiry.services || '')];
  }
  return {
    fullName: inquiry.full_name || inquiry.fullName || '',
    brandName: inquiry.brand_name || inquiry.brandName || '',
    referenceId: inquiry.reference_id || inquiry.referenceId || '',
    platform: inquiry.primary_platform || inquiry.primaryPlatform || 'Instagram',
    services: servicesList.join(', '),
    contactTime: inquiry.preferred_contact_time || inquiry.preferredContactTime || 'Preferred Slot',
    email: inquiry.email || '',
    phone: inquiry.phone || '',
  };
}

async function triggerNewInquiryEmails(db, inquiry) {
  const cfg = getRawSettings(db);
  if (!cfg) return;
  const vars = buildInquiryVars(inquiry);

  // 1. Instant Client Confirmation
  if (cfg.auto_reply_enabled && vars.email) {
    const subject = renderTemplate(cfg.auto_reply_subject || DEFAULT_AUTO_REPLY_SUBJECT, vars);
    const text = renderTemplate(cfg.auto_reply_template || DEFAULT_AUTO_REPLY_BODY, vars);
    await dispatchEmail(db, {
      inquiryId: inquiry.id,
      to: vars.email,
      subject,
      text,
      emailType: 'AUTO_CONFIRMATION',
    });
    db.prepare('UPDATE inquiries SET last_emailed_at = CURRENT_TIMESTAMP WHERE id = ?').run(inquiry.id);
  }

  // 2. Instant Internal Agency Lead Alert (sent only to configured internal alert address)
  if (cfg.admin_alert_enabled && cfg.admin_notify_email) {
    const alertSubject = `[New Brand Inquiry] ${vars.brandName} (${vars.referenceId})`;
    const alertBody = [
      `New client blueprint submitted on Suukun Media:`,
      ``,
      `Reference ID: ${vars.referenceId}`,
      `Brand: ${vars.brandName}`,
      `Contact: ${vars.fullName} (${vars.email} | ${vars.phone})`,
      `Platform: ${vars.platform}`,
      `Services: ${vars.services}`,
      `Preferred Contact: ${vars.contactTime}`,
      ``,
      `Log in privately to your Admin Portal (/#admin) to inspect and follow up.`,
    ].join('\n');

    await dispatchEmail(db, {
      inquiryId: inquiry.id,
      to: cfg.admin_notify_email,
      subject: alertSubject,
      text: alertBody,
      emailType: 'ADMIN_ALERT',
    });
  }
}

async function runRemailCycle(db) {
  const cfg = getRawSettings(db);
  if (!cfg || !cfg.remail_enabled) {
    return { ran: false, reason: 'Automated re-mailing is disabled.', processed: 0, results: [] };
  }

  const delayHours = Math.max(1, Number(cfg.remail_delay_hours) || 24);
  const maxAttempts = Math.max(1, Number(cfg.remail_max_attempts) || 2);

  // Find active leads awaiting follow-up whose cooldown window has elapsed
  const dueLeads = db.prepare(`
    SELECT * FROM inquiries
    WHERE status IN ('NEW', 'CONTACTED')
      AND COALESCE(remail_paused, 0) = 0
      AND COALESCE(remail_count, 0) < ?
      AND datetime(COALESCE(last_emailed_at, created_at), '+' || ? || ' hours') <= datetime('now')
    ORDER BY created_at ASC
    LIMIT 25
  `).all(maxAttempts, delayHours);

  const results = [];
  for (const lead of dueLeads) {
    const stepNum = (lead.remail_count || 0) + 1;
    const vars = buildInquiryVars(lead);
    const subject = renderTemplate(cfg.remail_subject || DEFAULT_REMAIL_SUBJECT, vars);
    const text = renderTemplate(cfg.remail_template || DEFAULT_REMAIL_BODY, vars);

    const outcome = await dispatchEmail(db, {
      inquiryId: lead.id,
      to: lead.email,
      subject,
      text,
      emailType: `AUTO_REMAIL_${stepNum}`,
    });

    db.prepare(`
      UPDATE inquiries
      SET remail_count = COALESCE(remail_count, 0) + 1,
          last_emailed_at = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(lead.id);

    results.push({ referenceId: lead.reference_id, step: stepNum, ...outcome });
  }

  return { ran: true, processed: results.length, results };
}

module.exports = {
  initEmailSchema,
  getMaskedSettings,
  updateEmailSettings,
  dispatchEmail,
  triggerNewInquiryEmails,
  runRemailCycle,
  buildInquiryVars,
  renderTemplate,
};
