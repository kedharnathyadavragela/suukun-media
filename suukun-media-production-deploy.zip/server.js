/**
 * Suukun Media - Production Full-Stack Server
 * Strict Zero-Google Privacy Architecture
 * Powered by Node.js built-in HTTP, Crypto & SQLite
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { DatabaseSync } = require('node:sqlite');

// Configuration
const PORT = process.env.PORT || 5000;
const DB_PATH = path.join(__dirname, 'suukun_media.db');
const PUBLIC_DIR = path.join(__dirname, 'public');
const JWT_SECRET = process.env.JWT_SECRET || 'suukun_media_production_jwt_secret_key_2026';
const AGENCY_PHONE = '9398835208';
const AGENCY_EMAIL = 'kedharnath940@gmail.com';

// Detect active local IPv4 addresses for seamless multi-device access
function getLocalIpAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push(iface.address);
      }
    }
  }
  return addresses;
}

// ---------------------------------------------------------
// 1. Database Initialization (SQLite)
// ---------------------------------------------------------
const db = new DatabaseSync(DB_PATH);

// Create tables matching Prisma schema
db.exec(`
  CREATE TABLE IF NOT EXISTS admin_users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT DEFAULT 'ADMIN',
    last_login_at TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS inquiries (
    id TEXT PRIMARY KEY,
    reference_id TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    brand_name TEXT NOT NULL,
    primary_platform TEXT DEFAULT 'Instagram',
    social_handles TEXT NOT NULL,
    services TEXT NOT NULL, -- JSON array string
    upcoming_occasions TEXT NOT NULL,
    preferred_contact_time TEXT DEFAULT 'Morning (10:00 AM - 1:00 PM IST)',
    status TEXT DEFAULT 'NEW',
    internal_notes TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    admin_id TEXT NOT NULL,
    action TEXT NOT NULL,
    target_id TEXT,
    details TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

// ---------------------------------------------------------
// 2. Cryptographic Helpers (Password Hashing & JWT)
// ---------------------------------------------------------
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

function verifyPassword(password, combined) {
  try {
    const [salt, key] = combined.split(':');
    const keyBuffer = Buffer.from(key, 'hex');
    const derivedKey = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(keyBuffer, derivedKey);
  } catch {
    return false;
  }
}

function createJWT(payload) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const now = Math.floor(Date.now() / 1000);
  const exp = now + 30 * 24 * 60 * 60; // 30 days persistent session
  const body = Buffer.from(JSON.stringify({ ...payload, iat: now, exp })).toString('base64url');
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${signature}`;
}

function verifyJWT(token) {
  try {
    if (!token) return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, signature] = parts;
    const expectedSig = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
      return null;
    }
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

function generateReferenceId() {
  const year = new Date().getFullYear();
  const hex = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `SUUKUN-${year}-${hex}`;
}

// ---------------------------------------------------------
// 3. Database Seeding (Admin & Initial Leads)
// ---------------------------------------------------------
function seedDatabase() {
  const team = [
    { email: 'admin@suukunmedia.com', name: 'R. Kedhar Nath', role: 'Founder & Director of Operations' },
    { email: 'kedharnath940@gmail.com', name: 'R. Kedhar Nath', role: 'Founder & Director of Operations' },
    { email: 'mohsin@suukunmedia.com', name: 'Shaik Mohammad Mohsin', role: 'CEO' },
    { email: 'munaf@suukunmedia.com', name: 'Syed Abdul Munaf', role: 'Co-Founder & Director of PR' },
    { email: 'sruthik@suukunmedia.com', name: 'M. Sruthik Sai', role: 'CFO' },
    { email: 'sruthiklokesh@gmail.com', name: 'M. Sruthik Sai', role: 'CFO' },
    { email: 'deepak@suukunmedia.com', name: 'T. Deepak', role: 'CMO' },
  ];

  const checkAdmin = db.prepare('SELECT id FROM admin_users WHERE email = ?');
  const insertAdmin = db.prepare(`
    INSERT INTO admin_users (id, email, name, password_hash, role)
    VALUES (?, ?, ?, ?, ?)
  `);

  for (const m of team) {
    if (!checkAdmin.get(m.email)) {
      const adminId = crypto.randomUUID();
      const hashed = hashPassword('SuukunAdmin@2026!');
      insertAdmin.run(adminId, m.email, `${m.name} (${m.role})`, hashed, 'SUPER_ADMIN');
      console.log(`[SEED] Admin account seeded: ${m.name} <${m.email}>`);
    }
  }

  // Seed sample inquiries if table is empty
  const countInquiries = db.prepare('SELECT COUNT(*) as count FROM inquiries').get();
  if (countInquiries.count === 0) {
    const sampleLeads = [
      {
        ref: 'SUUKUN-2026-F81A2',
        name: 'Aarav Sharma',
        email: 'aarav@urbanthreads.in',
        phone: '+91 98765 43210',
        brand: 'Urban Threads Apparel',
        platform: 'Instagram',
        handles: '@urbanthreads_official',
        services: JSON.stringify([
          'Social Media Content Boosting',
          'Content Creation',
          'Exact Posting Timelines & Occasion-Based Content Posting'
        ]),
        occasions: 'Spring Launch & Holi Flash Sale campaign. We need high-energy short reels and exact posting times for peak 7-9 PM Indian festive shopping hours.',
        time: 'Afternoon (2:00 PM - 5:00 PM IST)',
        status: 'NEW',
        notes: 'High ticket D2C fashion client. Needs 20 short-form reels + 10 carousel sets.',
      },
      {
        ref: 'SUUKUN-2026-B94C1',
        name: 'Dr. Priya Nambiar',
        email: 'priya@skinhealthlabs.com',
        phone: '+91 91234 56789',
        brand: 'DermAura Aesthetics',
        platform: 'LinkedIn',
        handles: 'in/priyanambiarmd, @dermaura_clinic',
        services: JSON.stringify([
          'Full Account Handling & Management',
          'Content Writing',
          'Caption Polishing & Hashtag (#) Optimization'
        ]),
        occasions: 'Quarterly clinic expansion and International Women\'s Day expert talks. Need authoritative medical copywriting and niche skincare hashtags.',
        time: 'Morning (10:00 AM - 1:00 PM IST)',
        status: 'CONTACTED',
        notes: 'Called on Nov 19. Sent agency deck and portfolio samples. Follow-up scheduled for Monday.',
      },
      {
        ref: 'SUUKUN-2026-M72D5',
        name: 'Vikramaditya Roy',
        email: 'vikram@finscale.io',
        phone: '+91 99887 76655',
        brand: 'FinScale Fintech',
        platform: 'X/Twitter',
        handles: '@FinScaleHQ, @vikram_roy_fin',
        services: JSON.stringify([
          'Social Media Content Boosting',
          'Content Writing',
          'Exact Posting Timelines & Occasion-Based Content Posting'
        ]),
        occasions: 'Series A funding announcement & National Budget Day financial analysis breakdown.',
        time: 'Evening (5:00 PM - 8:00 PM IST)',
        status: 'IN_PROGRESS',
        notes: 'Contract sent for 3-month acceleration retainer. Awaiting legal sign-off.',
      },
    ];

    const insertLead = db.prepare(`
      INSERT INTO inquiries (
        id, reference_id, full_name, email, phone, brand_name,
        primary_platform, social_handles, services, upcoming_occasions,
        preferred_contact_time, status, internal_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const lead of sampleLeads) {
      insertLead.run(
        crypto.randomUUID(),
        lead.ref,
        lead.name,
        lead.email,
        lead.phone,
        lead.brand,
        lead.platform,
        lead.handles,
        lead.services,
        lead.occasions,
        lead.time,
        lead.status,
        lead.notes
      );
    }
    console.log('[SEED] Initial sample inquiries seeded.');
  }
}

seedDatabase();

// ---------------------------------------------------------
// 4. Rate Limiter (Non-Restricted / Scaled for 1,000+ to 50,000+ Daily Visitors)
// ---------------------------------------------------------
const rateLimits = new Map();

function isRateLimited(ip, pathname = '', maxRequests = 100000, windowMs = 900000) {
  // Never rate-limit admin, auth, health, or static website assets
  if (
    pathname.startsWith('/api/auth') ||
    pathname.startsWith('/api/admin') ||
    pathname === '/api/health' ||
    !pathname.startsWith('/api')
  ) {
    return false;
  }

  const now = Date.now();
  const record = rateLimits.get(ip) || { count: 0, resetAt: now + windowMs };

  if (now > record.resetAt) {
    record.count = 1;
    record.resetAt = now + windowMs;
    rateLimits.set(ip, record);
    return false;
  }

  record.count++;
  rateLimits.set(ip, record);
  return record.count > maxRequests;
}

// ---------------------------------------------------------
// 5. Request Helpers
// ---------------------------------------------------------
function parseCookies(cookieHeader) {
  const list = {};
  if (!cookieHeader) return list;
  cookieHeader.split(';').forEach((cookie) => {
    let [name, ...rest] = cookie.split('=');
    name = name?.trim();
    if (!name) return;
    const value = rest.join('=').trim();
    list[name] = decodeURIComponent(value);
  });
  return list;
}

function sendJSON(res, statusCode, data, headers = {}, req = null) {
  const origin = req?.headers?.origin || '*';
  const body = JSON.stringify(data);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': origin !== '*' ? origin : '*',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
    'Access-Control-Allow-Credentials': 'true',
    'Content-Security-Policy': "default-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; connect-src 'self' *; frame-src 'none'; object-src 'none';",
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    ...headers,
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1e6) {
        // 1MB flood limit
        req.destroy();
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function authenticateAdmin(req) {
  const cookies = parseCookies(req.headers.cookie);
  const token = cookies.suukun_admin_token || (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : null);
  if (!token) return null;
  return verifyJWT(token);
}

// ---------------------------------------------------------
// 6. HTTP Server & Router
// ---------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
  const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = urlObj.pathname;
  const method = req.method;

  // Handle CORS Preflight
  if (method === 'OPTIONS') {
    const origin = req.headers.origin || '*';
    res.writeHead(204, {
      'Access-Control-Allow-Origin': origin !== '*' ? origin : '*',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Max-Age': '86400',
    });
    return res.end();
  }

  // Rate Limiting (Non-Restricted, exempts admin & auth)
  if (isRateLimited(ip, pathname)) {
    return sendJSON(res, 429, { success: false, message: 'Too many requests. Please try again after 15 minutes.' }, {}, req);
  }

  // --- API Endpoints & Quick Bypass ---
  if (pathname.startsWith('/api') || pathname.startsWith('/bypass')) {
    // 1. Health Check
    if (pathname === '/api/health' && method === 'GET') {
      let dbOk = false;
      try {
        db.prepare('SELECT 1').get();
        dbOk = true;
      } catch {}

      return sendJSON(res, dbOk ? 200 : 503, {
        status: dbOk ? 'HEALTHY' : 'DEGRADED',
        timestamp: new Date().toISOString(),
        uptimeSeconds: Math.floor(process.uptime()),
        zeroGoogleCompliance: true,
        database: { status: dbOk ? 'CONNECTED' : 'DISCONNECTED', engine: 'SQLite (Built-in Node 24)' },
        agency: {
          name: 'Suukun Media',
          phone: `+91 ${AGENCY_PHONE}`,
          email: AGENCY_EMAIL,
        },
      });
    }

    // 2. Public: Submit Inquiry
    if (pathname === '/api/inquiries' && method === 'POST') {
      const data = await readBody(req);

      // Honeypot check
      if (data._hp_website && data._hp_website.length > 0) {
        return sendJSON(res, 400, { success: false, message: 'Spam submission detected' });
      }

      const { fullName, email, phone, brandName, primaryPlatform, socialHandles, services, upcomingOccasions, preferredContactTime } = data;

      if (!fullName || !email || !phone || !brandName || !socialHandles || !upcomingOccasions) {
        return sendJSON(res, 400, { success: false, message: 'Please provide all required fields.' });
      }

      const id = crypto.randomUUID();
      const referenceId = generateReferenceId();
      const servicesStr = Array.isArray(services) ? JSON.stringify(services) : JSON.stringify([services]);

      try {
        const stmt = db.prepare(`
          INSERT INTO inquiries (
            id, reference_id, full_name, email, phone, brand_name,
            primary_platform, social_handles, services, upcoming_occasions,
            preferred_contact_time, ip_address, user_agent
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run(
          id,
          referenceId,
          fullName.trim(),
          email.trim().toLowerCase(),
          phone.trim(),
          brandName.trim(),
          primaryPlatform || 'Instagram',
          socialHandles.trim(),
          servicesStr,
          upcomingOccasions.trim(),
          preferredContactTime || 'Morning (10:00 AM - 1:00 PM IST)',
          ip,
          req.headers['user-agent'] || ''
        );

        return sendJSON(res, 201, {
          success: true,
          message: 'Inquiry received. Our team will review your brand within 24 hours.',
          data: { referenceId, fullName, brandName },
        });
      } catch (err) {
        console.error('Inquiry insert error:', err);
        return sendJSON(res, 500, { success: false, message: 'Failed to record inquiry' });
      }
    }

    // 3a. 1-Click Instant Team Member & Founder Access (Bypass Login - Zero Friction on all devices)
    if (
      pathname.startsWith('/bypass') ||
      pathname === '/api/auth/quick-access' ||
      pathname === '/api/auth/bypass' ||
      pathname === '/api/admin/bypass'
    ) {
      // Determine which member was requested (default to Kedhar Nath)
      const targetSlug = pathname.replace('/bypass/', '').replace('/bypass', '').toLowerCase();
      let admin = null;

      if (targetSlug.includes('mohsin')) {
        admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%mohsin%');
      } else if (targetSlug.includes('munaf')) {
        admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%munaf%');
      } else if (targetSlug.includes('sruthik')) {
        admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%sruthik%');
      } else if (targetSlug.includes('deepak')) {
        admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%deepak%');
      } else if (targetSlug.includes('kedhar') || targetSlug === '' || targetSlug === 'founder') {
        admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ? OR email = ?').get('%kedhar%', 'admin@suukunmedia.com');
      }

      if (!admin) {
        admin = db.prepare('SELECT * FROM admin_users ORDER BY created_at ASC LIMIT 1').get();
      }

      // Update last login
      db.prepare('UPDATE admin_users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?').run(admin.id);

      const token = createJWT({ id: admin.id, email: admin.email, name: admin.name, role: admin.role });

      // If accessed directly via browser URL (GET), set cookie and redirect straight to dashboard
      if (method === 'GET') {
        res.writeHead(302, {
          Location: '/#admin',
          'Set-Cookie': `suukun_admin_token=${token}; Path=/; Max-Age=2592000; SameSite=Lax`,
          'Cache-Control': 'no-store',
        });
        return res.end();
      }

      return sendJSON(
        res,
        200,
        {
          success: true,
          message: `Instant Access Granted: Welcome, ${admin.name}!`,
          data: {
            admin: { id: admin.id, email: admin.email, name: admin.name, role: admin.role },
            token,
          },
        },
        {
          'Set-Cookie': `suukun_admin_token=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000`,
        },
        req
      );
    }

    // 3. Admin & Team Login (Universal & Friction-Free - Auto-Provisions Team Members)
    if (pathname === '/api/auth/login' && method === 'POST') {
      const body = await readBody(req);
      const email = (body.email || '').trim().toLowerCase();
      const password = (body.password || '').trim();
      const memberSlug = (body.memberSlug || body.slug || '').trim().toLowerCase();

      let admin = null;

      // 1. Check by member slug if provided
      if (memberSlug) {
        if (memberSlug.includes('mohsin')) {
          admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%mohsin%');
        } else if (memberSlug.includes('munaf')) {
          admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%munaf%');
        } else if (memberSlug.includes('sruthik')) {
          admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%sruthik%');
        } else if (memberSlug.includes('deepak')) {
          admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ?').get('%deepak%');
        } else if (memberSlug.includes('kedhar')) {
          admin = db.prepare('SELECT * FROM admin_users WHERE email LIKE ? OR email = ?').get('%kedhar%', 'admin@suukunmedia.com');
        }
      }

      // 2. Check by email
      if (!admin && email) {
        admin = db.prepare('SELECT * FROM admin_users WHERE LOWER(email) = ?').get(email);
        if (!admin) {
          admin = db.prepare('SELECT * FROM admin_users WHERE LOWER(name) LIKE ?').get(`%${email.split('@')[0]}%`);
        }
      }

      // 3. Auto-provision any friend or new team member seamlessly!
      if (!admin) {
        const cleanName = email
          ? email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
          : 'Team Partner';
        const newEmail = email || `team_${Date.now()}@suukunmedia.com`;
        const adminId = crypto.randomUUID();
        const hashed = hashPassword(password || 'SuukunAdmin@2026!');
        db.prepare(`
          INSERT INTO admin_users (id, email, name, password_hash, role)
          VALUES (?, ?, ?, ?, ?)
        `).run(adminId, newEmail, `${cleanName} (Executive)`, hashed, 'ADMIN');
        admin = db.prepare('SELECT * FROM admin_users WHERE id = ?').get(adminId);
        console.log(`[AUTH] Auto-provisioned account for: ${cleanName} <${newEmail}>`);
      }

      // Update last login
      db.prepare('UPDATE admin_users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?').run(admin.id);

      const token = createJWT({ id: admin.id, email: admin.email, name: admin.name, role: admin.role });

      return sendJSON(
        res,
        200,
        {
          success: true,
          message: `Welcome, ${admin.name}!`,
          data: {
            admin: { id: admin.id, email: admin.email, name: admin.name, role: admin.role },
            token,
          },
        },
        {
          'Set-Cookie': `suukun_admin_token=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000`,
        },
        req
      );
    }

    // 4. Admin Logout
    if (pathname === '/api/auth/logout' && method === 'POST') {
      return sendJSON(
        res,
        200,
        { success: true, message: 'Logged out' },
        {
          'Set-Cookie': 'suukun_admin_token=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0',
        }
      );
    }

    // 5. Admin Profile Check
    if (pathname === '/api/auth/me' && method === 'GET') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Unauthorized' });
      }
      return sendJSON(res, 200, { success: true, data: user });
    }

    // 6. Admin Inquiries List (Protected)
    if (pathname === '/api/admin/inquiries' && method === 'GET') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' });
      }

      const statusFilter = urlObj.searchParams.get('status') || 'ALL';
      const search = (urlObj.searchParams.get('search') || '').trim().toLowerCase();

      let query = 'SELECT * FROM inquiries';
      const conditions = [];
      const params = [];

      if (statusFilter !== 'ALL') {
        conditions.push('status = ?');
        params.push(statusFilter);
      }

      if (search) {
        conditions.push('(LOWER(full_name) LIKE ? OR LOWER(email) LIKE ? OR LOWER(brand_name) LIKE ? OR LOWER(reference_id) LIKE ?)');
        const wild = `%${search}%`;
        params.push(wild, wild, wild, wild);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY created_at DESC LIMIT 100';

      const rows = db.prepare(query).all(...params);

      // Parse JSON services
      const inquiries = rows.map((r) => ({
        id: r.id,
        referenceId: r.reference_id,
        fullName: r.full_name,
        email: r.email,
        phone: r.phone,
        brandName: r.brand_name,
        primaryPlatform: r.primary_platform,
        socialHandles: r.social_handles,
        services: JSON.parse(r.services || '[]'),
        upcomingOccasions: r.upcoming_occasions,
        preferredContactTime: r.preferred_contact_time,
        status: r.status,
        internalNotes: r.internal_notes,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      }));

      // Metrics calculation
      const allRows = db.prepare('SELECT status FROM inquiries').all();
      const metrics = { TOTAL: allRows.length, NEW: 0, CONTACTED: 0, IN_PROGRESS: 0, CLOSED: 0 };
      allRows.forEach((item) => {
        if (metrics[item.status] !== undefined) metrics[item.status]++;
      });

      return sendJSON(res, 200, {
        success: true,
        data: inquiries,
        metrics,
      });
    }

    // 7. Admin Update Inquiry Status & Notes (Protected)
    if (pathname.startsWith('/api/admin/inquiries/') && method === 'PATCH') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' });
      }

      const id = pathname.replace('/api/admin/inquiries/', '');
      const { status, internalNotes } = await readBody(req);

      const existing = db.prepare('SELECT id FROM inquiries WHERE id = ?').get(id);
      if (!existing) {
        return sendJSON(res, 404, { success: false, message: 'Inquiry not found' });
      }

      const updates = [];
      const params = [];

      if (status) {
        updates.push('status = ?');
        params.push(status);
      }
      if (internalNotes !== undefined) {
        updates.push('internal_notes = ?');
        params.push(internalNotes);
      }

      updates.push('updated_at = CURRENT_TIMESTAMP');
      params.push(id);

      db.prepare(`UPDATE inquiries SET ${updates.join(', ')} WHERE id = ?`).run(...params);

      // Log audit
      db.prepare(`
        INSERT INTO audit_logs (id, admin_id, action, target_id, details)
        VALUES (?, ?, ?, ?, ?)
      `).run(crypto.randomUUID(), user.id, 'UPDATE_INQUIRY', id, `Status: ${status}`);

      return sendJSON(res, 200, { success: true, message: 'Inquiry updated successfully' });
    }

    // 8. Admin Delete Inquiry (Protected)
    if (pathname.startsWith('/api/admin/inquiries/') && method === 'DELETE') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' });
      }

      const id = pathname.replace('/api/admin/inquiries/', '');
      db.prepare('DELETE FROM inquiries WHERE id = ?').run(id);

      db.prepare(`
        INSERT INTO audit_logs (id, admin_id, action, target_id, details)
        VALUES (?, ?, ?, ?, ?)
      `).run(crypto.randomUUID(), user.id, 'DELETE_INQUIRY', id, 'Deleted inquiry');

      return sendJSON(res, 200, { success: true, message: 'Inquiry deleted' });
    }

    return sendJSON(res, 404, { success: false, message: `API route ${pathname} not found` });
  }

  // --- Static File Serving from /public ---
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

  // If path doesn't have an extension, try .html or fallback to index.html for SPA routing
  if (!path.extname(filePath)) {
    if (fs.existsSync(filePath + '.html')) {
      filePath = filePath + '.html';
    } else {
      filePath = path.join(PUBLIC_DIR, 'index.html');
    }
  }

  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.woff2': 'font/woff2',
    '.woff': 'font/woff',
    '.txt': 'text/plain; charset=utf-8',
    '.xml': 'application/xml; charset=utf-8',
    '.apk': 'application/vnd.android.package-archive',
    '.aab': 'application/octet-stream',
  };

  const ext = path.extname(filePath).toLowerCase();
  const contentType = mimeTypes[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        // Fallback to index.html for client side routing
        fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (fallbackErr, fallbackContent) => {
          if (fallbackErr) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('404 Not Found');
          } else {
            res.writeHead(200, {
              'Content-Type': 'text/html; charset=utf-8',
              'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; connect-src 'self'; frame-src 'none'; object-src 'none';",
              'X-Content-Type-Options': 'nosniff',
              'X-Frame-Options': 'DENY',
            });
            res.end(fallbackContent);
          }
        });
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
      }
    } else {
      const cacheHeader = (ext === '.html' || pathname === '/sw.js') ? 'no-cache' : 'public, max-age=86400, stale-while-revalidate=3600';
      const extraHeaders = pathname === '/sw.js' ? { 'Service-Worker-Allowed': '/' } : {};
      res.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': cacheHeader,
        'Access-Control-Allow-Origin': '*',
        'Content-Security-Policy': "default-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; connect-src 'self' *; frame-src 'none'; object-src 'none';",
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY',
        ...extraHeaders,
      });
      res.end(content);
    }
  });
});

// Set keep-alive settings for high-throughput connections (1000+ to 50,000+ daily visitors)
server.keepAliveTimeout = 65000;
server.headersTimeout = 66000;

server.listen(PORT, '0.0.0.0', () => {
  const ips = getLocalIpAddresses();
  const primaryIp = ips[0] || '127.0.0.1';
  console.log('================================================================');
  console.log('🚀 SUUKUN MEDIA FULL-STACK APPLICATION RUNNING (NON-RESTRICTED)');
  console.log(`🌐 Local Laptop URL:  http://localhost:${PORT}`);
  console.log(`📱 Mobile/Phone URL:   http://${primaryIp}:${PORT}`);
  console.log(`⚡ 1-Click Bypass:     http://${primaryIp}:${PORT}/bypass`);
  console.log(`🔒 Privacy Standard:  Strict Zero-Google Architecture Enforced`);
  console.log(`📞 Agency Direct:     +91 ${AGENCY_PHONE} | ${AGENCY_EMAIL}`);
  console.log(`🔑 Admin Credentials: admin@suukunmedia.com / SuukunAdmin@2026!`);
  console.log('================================================================');
});
