/**
 * Suukun Media - Production Full-Stack Server
 * Strict Zero-Google Privacy Architecture
 * Powered by Node.js built-in HTTP, Crypto & SQLite
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { DatabaseSync } = require('node:sqlite');
const emailAutomation = require('./emailAutomation');

// Configuration
const PORT = process.env.PORT || 5000;
const DB_PATH = path.join(__dirname, 'suukun_media.db');
const PUBLIC_DIR = path.join(__dirname, 'public');
const JWT_SECRET = process.env.JWT_SECRET || 'suukun_media_production_jwt_secret_key_2026';
const DEFAULT_ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@suukunmedia.com').trim().toLowerCase();
const DEFAULT_ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'SuukunAdmin@2026!';

// Detect active local IPv4 addresses for seamless multi-device access
function getLocalIpAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push(iface.address);
      }
    }
  }
  return addresses;
}

// ---------------------------------------------------------
// 1. Database Initialization (SQLite)
// ---------------------------------------------------------
const db = new DatabaseSync(DB_PATH);

// Create tables matching Prisma schema
db.exec(`
  CREATE TABLE IF NOT EXISTS admin_users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT DEFAULT 'ADMIN',
    last_login_at TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS inquiries (
    id TEXT PRIMARY KEY,
    reference_id TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    brand_name TEXT NOT NULL,
    primary_platform TEXT DEFAULT 'Instagram',
    social_handles TEXT NOT NULL,
    services TEXT NOT NULL, -- JSON array string
    upcoming_occasions TEXT NOT NULL,
    preferred_contact_time TEXT DEFAULT 'Morning (10:00 AM - 1:00 PM IST)',
    status TEXT DEFAULT 'NEW',
    internal_notes TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    admin_id TEXT NOT NULL,
    action TEXT NOT NULL,
    target_id TEXT,
    details TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

emailAutomation.initEmailSchema(db);

// ---------------------------------------------------------
// 2. Cryptographic Helpers (Password Hashing & JWT)
// ---------------------------------------------------------
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

function verifyPassword(password, combined) {
  try {
    const [salt, key] = combined.split(':');
    const keyBuffer = Buffer.from(key, 'hex');
    const derivedKey = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(keyBuffer, derivedKey);
  } catch {
    return false;
  }
}

function createJWT(payload) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const now = Math.floor(Date.now() / 1000);
  const exp = now + 30 * 24 * 60 * 60; // 30 days persistent session
  const body = Buffer.from(JSON.stringify({ ...payload, iat: now, exp })).toString('base64url');
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${signature}`;
}

function verifyJWT(token) {
  try {
    if (!token) return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, signature] = parts;
    const expectedSig = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
      return null;
    }
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

function generateReferenceId() {
  const year = new Date().getFullYear();
  const hex = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `SUUKUN-${year}-${hex}`;
}

// ---------------------------------------------------------
// 3. Database Seeding (Admin & Initial Leads)
// ---------------------------------------------------------
function seedDatabase() {
  const team = [
    { email: DEFAULT_ADMIN_EMAIL, name: 'R. Kedhar Nath', role: 'Founder & Director of Operations' },
    { email: 'mohsin@suukunmedia.com', name: 'Shaik Mohammad Mohsin', role: 'CEO' },
    { email: 'munaf@suukunmedia.com', name: 'Syed Abdul Munaf', role: 'Co-Founder & Director of PR' },
    { email: 'sruthik@suukunmedia.com', name: 'M. Sruthik Sai', role: 'CFO' },
    { email: 'deepak@suukunmedia.com', name: 'T. Deepak', role: 'CMO' },
  ];

  const checkAdmin = db.prepare('SELECT id FROM admin_users WHERE email = ?');
  const insertAdmin = db.prepare(`
    INSERT INTO admin_users (id, email, name, password_hash, role)
    VALUES (?, ?, ?, ?, ?)
  `);

  for (const m of team) {
    if (!checkAdmin.get(m.email)) {
      const adminId = crypto.randomUUID();
      const hashed = hashPassword(DEFAULT_ADMIN_PASSWORD);
      insertAdmin.run(adminId, m.email, `${m.name} (${m.role})`, hashed, 'SUPER_ADMIN');
    }
  }

  // Seed sample inquiries if table is empty
  const countInquiries = db.prepare('SELECT COUNT(*) as count FROM inquiries').get();
  if (countInquiries.count === 0) {
    const sampleLeads = [
      {
        ref: 'SUUKUN-2026-F81A2',
        name: 'Aarav Sharma',
        email: 'aarav@urbanthreads.in',
        phone: '+91 98765 43210',
        brand: 'Urban Threads Apparel',
        platform: 'Instagram',
        handles: '@urbanthreads_official',
        services: JSON.stringify([
          'Social Media Content Boosting',
          'Content Creation',
          'Exact Posting Timelines & Occasion-Based Content Posting'
        ]),
        occasions: 'Spring Launch & Holi Flash Sale campaign. We need high-energy short reels and exact posting times for peak 7-9 PM Indian festive shopping hours.',
        time: 'Afternoon (2:00 PM - 5:00 PM IST)',
        status: 'NEW',
        notes: 'High ticket D2C fashion client. Needs 20 short-form reels + 10 carousel sets.',
      },
      {
        ref: 'SUUKUN-2026-B94C1',
        name: 'Dr. Priya Nambiar',
        email: 'priya@skinhealthlabs.com',
        phone: '+91 91234 56789',
        brand: 'DermAura Aesthetics',
        platform: 'LinkedIn',
        handles: 'in/priyanambiarmd, @dermaura_clinic',
        services: JSON.stringify([
          'Full Account Handling & Management',
          'Content Writing',
          'Caption Polishing & Hashtag (#) Optimization'
        ]),
        occasions: 'Quarterly clinic expansion and International Women\'s Day expert talks. Need authoritative medical copywriting and niche skincare hashtags.',
        time: 'Morning (10:00 AM - 1:00 PM IST)',
        status: 'CONTACTED',
        notes: 'Called on Nov 19. Sent agency deck and portfolio samples. Follow-up scheduled for Monday.',
      },
      {
        ref: 'SUUKUN-2026-M72D5',
        name: 'Vikramaditya Roy',
        email: 'vikram@finscale.io',
        phone: '+91 99887 76655',
        brand: 'FinScale Fintech',
        platform: 'X/Twitter',
        handles: '@FinScaleHQ, @vikram_roy_fin',
        services: JSON.stringify([
          'Social Media Content Boosting',
          'Content Writing',
          'Exact Posting Timelines & Occasion-Based Content Posting'
        ]),
        occasions: 'Series A funding announcement & National Budget Day financial analysis breakdown.',
        time: 'Evening (5:00 PM - 8:00 PM IST)',
        status: 'IN_PROGRESS',
        notes: 'Contract sent for 3-month acceleration retainer. Awaiting legal sign-off.',
      },
    ];

    const insertLead = db.prepare(`
      INSERT INTO inquiries (
        id, reference_id, full_name, email, phone, brand_name,
        primary_platform, social_handles, services, upcoming_occasions,
        preferred_contact_time, status, internal_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const lead of sampleLeads) {
      insertLead.run(
        crypto.randomUUID(),
        lead.ref,
        lead.name,
        lead.email,
        lead.phone,
        lead.brand,
        lead.platform,
        lead.handles,
        lead.services,
        lead.occasions,
        lead.time,
        lead.status,
        lead.notes
      );
    }
    console.log('[SEED] Initial sample inquiries seeded.');
  }
}

seedDatabase();

// ---------------------------------------------------------
// 4. Rate Limiter (Non-Restricted / Scaled for 1,000+ to 50,000+ Daily Visitors)
// ---------------------------------------------------------
const rateLimits = new Map();
const loginAttempts = new Map();

function isLoginRateLimited(ip, maxAttempts = 15, windowMs = 900000) {
  const now = Date.now();
  const record = loginAttempts.get(ip) || { count: 0, resetAt: now + windowMs };
  if (now > record.resetAt) {
    record.count = 1;
    record.resetAt = now + windowMs;
    loginAttempts.set(ip, record);
    return false;
  }
  record.count++;
  loginAttempts.set(ip, record);
  return record.count > maxAttempts;
}

function isRateLimited(ip, pathname = '', maxRequests = 100000, windowMs = 900000) {
  // Separate strict limit protects /api/auth/login; exempt health & static assets
  if (
    pathname.startsWith('/api/auth') ||
    pathname.startsWith('/api/admin') ||
    pathname === '/api/health' ||
    !pathname.startsWith('/api')
  ) {
    return false;
  }

  const now = Date.now();
  const record = rateLimits.get(ip) || { count: 0, resetAt: now + windowMs };

  if (now > record.resetAt) {
    record.count = 1;
    record.resetAt = now + windowMs;
    rateLimits.set(ip, record);
    return false;
  }

  record.count++;
  rateLimits.set(ip, record);
  return record.count > maxRequests;
}

// ---------------------------------------------------------
// 5. Request Helpers
// ---------------------------------------------------------
function parseCookies(cookieHeader) {
  const list = {};
  if (!cookieHeader) return list;
  cookieHeader.split(';').forEach((cookie) => {
    let [name, ...rest] = cookie.split('=');
    name = name?.trim();
    if (!name) return;
    const value = rest.join('=').trim();
    list[name] = decodeURIComponent(value);
  });
  return list;
}

function sendJSON(res, statusCode, data, headers = {}, req = null) {
  const origin = req?.headers?.origin || '*';
  const body = JSON.stringify(data);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': origin !== '*' ? origin : '*',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
    'Access-Control-Allow-Credentials': 'true',
    'Content-Security-Policy': "default-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; connect-src 'self' *; frame-src 'none'; object-src 'none';",
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    ...headers,
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1e6) {
        // 1MB flood limit
        req.destroy();
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function authenticateAdmin(req) {
  const cookies = parseCookies(req.headers.cookie);
  const token = cookies.suukun_admin_token || (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : null);
  if (!token) return null;
  return verifyJWT(token);
}

// ---------------------------------------------------------
// 6. HTTP Server & Router
// ---------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
  const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = urlObj.pathname;
  const method = req.method;

  // Handle CORS Preflight
  if (method === 'OPTIONS') {
    const origin = req.headers.origin || '*';
    res.writeHead(204, {
      'Access-Control-Allow-Origin': origin !== '*' ? origin : '*',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Max-Age': '86400',
    });
    return res.end();
  }

  // Rate Limiting (Non-Restricted, exempts admin & auth)
  if (isRateLimited(ip, pathname)) {
    return sendJSON(res, 429, { success: false, message: 'Too many requests. Please try again after 15 minutes.' }, {}, req);
  }

  // --- API Endpoints ---
  if (pathname.startsWith('/api')) {
    // 1. Health Check (Zero sensitive admin info exposed)
    if (pathname === '/api/health' && method === 'GET') {
      let dbOk = false;
      try {
        db.prepare('SELECT 1').get();
        dbOk = true;
      } catch {}

      return sendJSON(res, dbOk ? 200 : 503, {
        status: dbOk ? 'HEALTHY' : 'DEGRADED',
        timestamp: new Date().toISOString(),
        uptimeSeconds: Math.floor(process.uptime()),
        zeroGoogleCompliance: true,
        database: { status: dbOk ? 'CONNECTED' : 'DISCONNECTED', engine: 'SQLite (Built-in Node 24)' },
      });
    }

    // 2. Public: Submit Inquiry (+ instant automated confirmation & internal alert)
    if (pathname === '/api/inquiries' && method === 'POST') {
      const data = await readBody(req);

      // Honeypot check
      if (data._hp_website && data._hp_website.length > 0) {
        return sendJSON(res, 400, { success: false, message: 'Spam submission detected' });
      }

      const { fullName, email, phone, brandName, primaryPlatform, socialHandles, services, upcomingOccasions, preferredContactTime } = data;

      if (!fullName || !email || !phone || !brandName || !socialHandles || !upcomingOccasions) {
        return sendJSON(res, 400, { success: false, message: 'Please provide all required fields.' });
      }

      const cleanEmail = String(email).trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        return sendJSON(res, 400, { success: false, message: 'Please provide a valid email address.' });
      }

      const id = crypto.randomUUID();
      const referenceId = generateReferenceId();
      const servicesStr = Array.isArray(services) ? JSON.stringify(services) : JSON.stringify([services]);

      try {
        const stmt = db.prepare(`
          INSERT INTO inquiries (
            id, reference_id, full_name, email, phone, brand_name,
            primary_platform, social_handles, services, upcoming_occasions,
            preferred_contact_time, ip_address, user_agent
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run(
          id,
          referenceId,
          fullName.trim(),
          cleanEmail,
          phone.trim(),
          brandName.trim(),
          primaryPlatform || 'Instagram',
          socialHandles.trim(),
          servicesStr,
          upcomingOccasions.trim(),
          preferredContactTime || 'Morning (10:00 AM - 1:00 PM IST)',
          ip,
          req.headers['user-agent'] || ''
        );

        // Fire automated confirmation & admin alert asynchronously
        const savedInquiry = db.prepare('SELECT * FROM inquiries WHERE id = ?').get(id);
        if (savedInquiry) {
          emailAutomation.triggerNewInquiryEmails(db, savedInquiry).catch((e) => {
            console.error('[EMAIL_AUTOMATION] New inquiry trigger error:', e.message);
          });
        }

        return sendJSON(res, 201, {
          success: true,
          message: 'Inquiry received. Our team will review your brand within 24 hours.',
          data: { referenceId, fullName: fullName.trim(), brandName: brandName.trim() },
        });
      } catch (err) {
        console.error('Inquiry insert error:', err);
        return sendJSON(res, 500, { success: false, message: 'Failed to record inquiry' });
      }
    }

    // 3. Private Admin Login (Strict Password Verification Required)
    if (pathname === '/api/auth/login' && method === 'POST') {
      if (isLoginRateLimited(ip)) {
        return sendJSON(res, 429, { success: false, message: 'Too many login attempts. Please wait 15 minutes.' }, {}, req);
      }

      const body = await readBody(req);
      const email = (body.email || '').trim().toLowerCase();
      const password = String(body.password || '');

      if (!email || !password) {
        return sendJSON(res, 400, { success: false, message: 'Email and password are required.' }, {}, req);
      }

      const admin = db.prepare('SELECT * FROM admin_users WHERE LOWER(email) = ?').get(email);
      if (!admin || !verifyPassword(password, admin.password_hash)) {
        return sendJSON(res, 401, { success: false, message: 'Invalid email or password.' }, {}, req);
      }

      db.prepare('UPDATE admin_users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?').run(admin.id);

      const token = createJWT({ id: admin.id, email: admin.email, name: admin.name, role: admin.role });
      const isHttps = req.headers['x-forwarded-proto'] === 'https' || Boolean(req.socket?.encrypted);
      const secureFlag = isHttps ? '; Secure' : '';

      return sendJSON(
        res,
        200,
        {
          success: true,
          message: `Welcome, ${admin.name}!`,
          data: {
            admin: { id: admin.id, email: admin.email, name: admin.name, role: admin.role },
            token,
          },
        },
        {
          'Set-Cookie': `suukun_admin_token=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secureFlag}`,
        },
        req
      );
    }

    // 3b. Authenticated Admin Credential Update (Change Private Email / Password)
    if (pathname === '/api/auth/change-credentials' && method === 'POST') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Authentication required' }, {}, req);
      }

      const body = await readBody(req);
      const currentPassword = String(body.currentPassword || '');
      const newEmail = body.newEmail ? body.newEmail.trim().toLowerCase() : null;
      const newPassword = body.newPassword ? String(body.newPassword) : null;
      const newName = body.newName ? body.newName.trim() : null;

      const admin = db.prepare('SELECT * FROM admin_users WHERE id = ?').get(user.id);
      if (!admin || !verifyPassword(currentPassword, admin.password_hash)) {
        return sendJSON(res, 401, { success: false, message: 'Current password is incorrect.' }, {}, req);
      }

      if (newPassword && newPassword.length < 8) {
        return sendJSON(res, 400, { success: false, message: 'New password must be at least 8 characters.' }, {}, req);
      }

      const targetEmail = newEmail || admin.email;
      const targetName = newName || admin.name;
      const targetHash = newPassword ? hashPassword(newPassword) : admin.password_hash;

      try {
        db.prepare(`
          UPDATE admin_users
          SET email = ?, name = ?, password_hash = ?, updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).run(targetEmail, targetName, targetHash, admin.id);

        const token = createJWT({ id: admin.id, email: targetEmail, name: targetName, role: admin.role });
        const isHttps = req.headers['x-forwarded-proto'] === 'https' || Boolean(req.socket?.encrypted);
        const secureFlag = isHttps ? '; Secure' : '';

        return sendJSON(
          res,
          200,
          {
            success: true,
            message: 'Admin credentials updated successfully.',
            data: { admin: { id: admin.id, email: targetEmail, name: targetName, role: admin.role }, token },
          },
          {
            'Set-Cookie': `suukun_admin_token=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secureFlag}`,
          },
          req
        );
      } catch (err) {
        return sendJSON(res, 400, { success: false, message: 'Could not update credentials (email may already be in use).' }, {}, req);
      }
    }

    // 4. Admin Logout
    if (pathname === '/api/auth/logout' && method === 'POST') {
      return sendJSON(
        res,
        200,
        { success: true, message: 'Logged out' },
        {
          'Set-Cookie': 'suukun_admin_token=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0',
        }
      );
    }

    // 5. Admin Profile Check
    if (pathname === '/api/auth/me' && method === 'GET') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Unauthorized' });
      }
      return sendJSON(res, 200, { success: true, data: user });
    }

    // 6. Admin Inquiries List (Protected)
    if (pathname === '/api/admin/inquiries' && method === 'GET') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' });
      }

      const statusFilter = urlObj.searchParams.get('status') || 'ALL';
      const search = (urlObj.searchParams.get('search') || '').trim().toLowerCase();

      let query = 'SELECT * FROM inquiries';
      const conditions = [];
      const params = [];

      if (statusFilter !== 'ALL') {
        conditions.push('status = ?');
        params.push(statusFilter);
      }

      if (search) {
        conditions.push('(LOWER(full_name) LIKE ? OR LOWER(email) LIKE ? OR LOWER(brand_name) LIKE ? OR LOWER(reference_id) LIKE ?)');
        const wild = `%${search}%`;
        params.push(wild, wild, wild, wild);
      }

      if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
      }

      query += ' ORDER BY created_at DESC LIMIT 100';

      const rows = db.prepare(query).all(...params);

      // Parse JSON services & include email automation tracking
      const inquiries = rows.map((r) => ({
        id: r.id,
        referenceId: r.reference_id,
        fullName: r.full_name,
        email: r.email,
        phone: r.phone,
        brandName: r.brand_name,
        primaryPlatform: r.primary_platform,
        socialHandles: r.social_handles,
        services: JSON.parse(r.services || '[]'),
        upcomingOccasions: r.upcoming_occasions,
        preferredContactTime: r.preferred_contact_time,
        status: r.status,
        internalNotes: r.internal_notes,
        remailCount: r.remail_count || 0,
        lastEmailedAt: r.last_emailed_at || null,
        remailPaused: Boolean(r.remail_paused),
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      }));

      // Metrics calculation
      const allRows = db.prepare('SELECT status FROM inquiries').all();
      const metrics = { TOTAL: allRows.length, NEW: 0, CONTACTED: 0, IN_PROGRESS: 0, CLOSED: 0 };
      allRows.forEach((item) => {
        if (metrics[item.status] !== undefined) metrics[item.status]++;
      });

      return sendJSON(res, 200, {
        success: true,
        data: inquiries,
        metrics,
      });
    }

    // 7. Admin Manually Send Follow-up / Re-mail for Specific Inquiry
    if (pathname.startsWith('/api/admin/inquiries/') && pathname.endsWith('/email') && method === 'POST') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' }, {}, req);
      }

      const id = pathname.slice('/api/admin/inquiries/'.length, -'/email'.length);
      const inquiry = db.prepare('SELECT * FROM inquiries WHERE id = ?').get(id);
      if (!inquiry) {
        return sendJSON(res, 404, { success: false, message: 'Inquiry not found' }, {}, req);
      }

      const body = await readBody(req);
      const vars = emailAutomation.buildInquiryVars(inquiry);
      const settings = emailAutomation.getMaskedSettings(db);
      const rawSubject = body.subject?.trim() || settings?.remailSubject || 'Follow-up from Suukun Media ({{referenceId}})';
      const rawText = body.message?.trim() || settings?.remailTemplate || '';
      const subject = emailAutomation.renderTemplate(rawSubject, vars);
      const text = emailAutomation.renderTemplate(rawText, vars);

      const result = await emailAutomation.dispatchEmail(db, {
        inquiryId: inquiry.id,
        to: inquiry.email,
        subject,
        text,
        emailType: 'MANUAL_FOLLOWUP',
      });

      db.prepare(`
        UPDATE inquiries
        SET remail_count = COALESCE(remail_count, 0) + 1,
            last_emailed_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(inquiry.id);

      db.prepare(`
        INSERT INTO audit_logs (id, admin_id, action, target_id, details)
        VALUES (?, ?, ?, ?, ?)
      `).run(crypto.randomUUID(), user.id, 'MANUAL_REMAIL', id, `Status: ${result.status}`);

      return sendJSON(res, 200, { success: true, data: result }, {}, req);
    }

    // 8. Admin Update Inquiry Status, Notes & Re-mail Pause (Protected)
    if (pathname.startsWith('/api/admin/inquiries/') && method === 'PATCH') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' });
      }

      const id = pathname.replace('/api/admin/inquiries/', '');
      const { status, internalNotes, remailPaused } = await readBody(req);

      const existing = db.prepare('SELECT id FROM inquiries WHERE id = ?').get(id);
      if (!existing) {
        return sendJSON(res, 404, { success: false, message: 'Inquiry not found' });
      }

      const updates = [];
      const params = [];

      if (status) {
        updates.push('status = ?');
        params.push(status);
      }
      if (internalNotes !== undefined) {
        updates.push('internal_notes = ?');
        params.push(internalNotes);
      }
      if (remailPaused !== undefined) {
        updates.push('remail_paused = ?');
        params.push(remailPaused ? 1 : 0);
      }

      updates.push('updated_at = CURRENT_TIMESTAMP');
      params.push(id);

      db.prepare(`UPDATE inquiries SET ${updates.join(', ')} WHERE id = ?`).run(...params);

      // Log audit
      db.prepare(`
        INSERT INTO audit_logs (id, admin_id, action, target_id, details)
        VALUES (?, ?, ?, ?, ?)
      `).run(crypto.randomUUID(), user.id, 'UPDATE_INQUIRY', id, `Status: ${status ?? 'unchanged'}`);

      return sendJSON(res, 200, { success: true, message: 'Inquiry updated successfully' });
    }

    // 9. Admin Delete Inquiry (Protected)
    if (pathname.startsWith('/api/admin/inquiries/') && method === 'DELETE') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' });
      }

      const id = pathname.replace('/api/admin/inquiries/', '');
      db.prepare('DELETE FROM inquiries WHERE id = ?').run(id);

      db.prepare(`
        INSERT INTO audit_logs (id, admin_id, action, target_id, details)
        VALUES (?, ?, ?, ?, ?)
      `).run(crypto.randomUUID(), user.id, 'DELETE_INQUIRY', id, 'Deleted inquiry');

      return sendJSON(res, 200, { success: true, message: 'Inquiry deleted' });
    }

    // 10. Email Automation Settings (Protected)
    if (pathname === '/api/admin/email/settings' && method === 'GET') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' }, {}, req);
      }

      const settings = emailAutomation.getMaskedSettings(db);
      const stats = {
        totalLogs: db.prepare('SELECT COUNT(*) as c FROM email_logs').get().c,
        sentCount: db.prepare("SELECT COUNT(*) as c FROM email_logs WHERE status = 'SENT'").get().c,
        remailCount: db.prepare("SELECT COUNT(*) as c FROM email_logs WHERE email_type LIKE 'AUTO_REMAIL_%' OR email_type = 'MANUAL_FOLLOWUP'").get().c,
        pendingAutoRemail: db.prepare("SELECT COUNT(*) as c FROM inquiries WHERE status IN ('NEW', 'CONTACTED') AND COALESCE(remail_paused, 0) = 0").get().c,
      };
      return sendJSON(res, 200, { success: true, data: { settings, stats } }, {}, req);
    }

    if (pathname === '/api/admin/email/settings' && method === 'PUT') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' }, {}, req);
      }

      const body = await readBody(req);
      const updated = emailAutomation.updateEmailSettings(db, body);
      return sendJSON(res, 200, { success: true, message: 'Email automation settings saved.', data: updated }, {}, req);
    }

    // 11. Email Automation Logs (Protected)
    if (pathname === '/api/admin/email/logs' && method === 'GET') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' }, {}, req);
      }

      const inquiryId = urlObj.searchParams.get('inquiryId');
      const rows = inquiryId
        ? db.prepare('SELECT * FROM email_logs WHERE inquiry_id = ? ORDER BY created_at DESC LIMIT 50').all(inquiryId)
        : db.prepare('SELECT * FROM email_logs ORDER BY created_at DESC LIMIT 100').all();

      return sendJSON(res, 200, { success: true, data: rows }, {}, req);
    }

    // 12. Send Test Email (Protected)
    if (pathname === '/api/admin/email/test' && method === 'POST') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' }, {}, req);
      }

      const body = await readBody(req);
      const targetEmail = (body.to || user.email || '').trim();
      if (!targetEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(targetEmail)) {
        return sendJSON(res, 400, { success: false, message: 'Valid recipient email address required.' }, {}, req);
      }

      const result = await emailAutomation.dispatchEmail(db, {
        inquiryId: null,
        to: targetEmail,
        subject: 'Suukun Media Email Automation Test',
        text: `Success! Your Suukun Media automated email & re-mailing engine verified delivery at ${new Date().toISOString()}.`,
        emailType: 'TEST',
      });

      return sendJSON(res, 200, { success: true, data: result }, {}, req);
    }

    // 13. Run Automated Re-mail Cycle Now (Protected)
    if (pathname === '/api/admin/email/run-remail' && method === 'POST') {
      const user = authenticateAdmin(req);
      if (!user) {
        return sendJSON(res, 401, { success: false, message: 'Admin authentication required' }, {}, req);
      }

      const summary = await emailAutomation.runRemailCycle(db);
      return sendJSON(res, 200, { success: true, data: summary }, {}, req);
    }

    return sendJSON(res, 404, { success: false, message: `API route ${pathname} not found` });
  }

  // --- Static File Serving from /public ---
  const safeRelPath = path.normalize(pathname === '/' ? 'index.html' : pathname).replace(/^(\.\.[\/\\])+/, '');
  let filePath = path.join(PUBLIC_DIR, safeRelPath);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    filePath = path.join(PUBLIC_DIR, 'index.html');
  }

  // If path doesn't have an extension, try .html or fallback to index.html for SPA routing
  if (!path.extname(filePath)) {
    if (fs.existsSync(filePath + '.html')) {
      filePath = filePath + '.html';
    } else {
      filePath = path.join(PUBLIC_DIR, 'index.html');
    }
  }

  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.woff2': 'font/woff2',
    '.woff': 'font/woff',
    '.txt': 'text/plain; charset=utf-8',
    '.xml': 'application/xml; charset=utf-8',
    '.apk': 'application/vnd.android.package-archive',
    '.aab': 'application/octet-stream',
  };

  const ext = path.extname(filePath).toLowerCase();
  const contentType = mimeTypes[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        // Fallback to index.html for client side routing
        fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (fallbackErr, fallbackContent) => {
          if (fallbackErr) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('404 Not Found');
          } else {
            res.writeHead(200, {
              'Content-Type': 'text/html; charset=utf-8',
              'Cache-Control': 'no-cache, must-revalidate',
              'Content-Security-Policy': "default-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; connect-src 'self' *; frame-src 'none'; object-src 'none';",
              'X-Content-Type-Options': 'nosniff',
              'X-Frame-Options': 'DENY',
            });
            res.end(fallbackContent);
          }
        });
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
      }
    } else {
      const noCacheTypes = ext === '.html' || ext === '.js' || ext === '.css' || pathname === '/sw.js' || pathname === '/manifest.json';
      const cacheHeader = noCacheTypes ? 'no-cache, must-revalidate' : 'public, max-age=86400, stale-while-revalidate=3600';
      const extraHeaders = pathname === '/sw.js' ? { 'Service-Worker-Allowed': '/' } : {};
      res.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': cacheHeader,
        'Access-Control-Allow-Origin': '*',
        'Content-Security-Policy': "default-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; img-src 'self' data: blob:; connect-src 'self' *; frame-src 'none'; object-src 'none';",
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY',
        ...extraHeaders,
      });
      res.end(content);
    }
  });
});

// Background Re-mail Follow-up Automation Scheduler (every 5 minutes)
setTimeout(() => {
  emailAutomation.runRemailCycle(db).catch((err) => console.error('[REMAIL_WORKER] Error:', err.message));
}, 20000);
setInterval(() => {
  emailAutomation.runRemailCycle(db).catch((err) => console.error('[REMAIL_WORKER] Error:', err.message));
}, 5 * 60 * 1000);

// Set keep-alive settings for high-throughput connections
server.keepAliveTimeout = 65000;
server.headersTimeout = 66000;

server.listen(PORT, '0.0.0.0', () => {
  const ips = getLocalIpAddresses();
  const primaryIp = ips[0] || '127.0.0.1';
  console.log('================================================================');
  console.log('🚀 SUUKUN MEDIA FULL-STACK APPLICATION RUNNING');
  console.log(`🌐 Local URL:        http://localhost:${PORT}`);
  console.log(`📱 LAN Mobile URL:   http://${primaryIp}:${PORT}`);
  console.log('🔒 Privacy Standard: Strict Zero-Google Architecture & Private Admin Auth');
  console.log('✉️  Email Automation: Active (SMTP / HTTPS API / Auto Re-mailing Scheduler)');
  console.log('================================================================');
});
